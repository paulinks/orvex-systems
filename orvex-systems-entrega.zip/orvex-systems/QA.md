# QA — Orvex Systems

Revisão local em **1º de novembro de 2026**. Escopo: implementação entregue neste workspace, sem domínio oficial, sem credenciais externas e sem dados comerciais reais.

## Resultado executivo

| Verificação | Resultado |
|---|---|
| Testes de servidor/API | **15/15 aprovados** |
| Testes de navegador desktop + mobile | **28/28 aprovados** |
| Build de produção | **Aprovado**; 871,1 KiB incluindo variantes gzip/Brotli |
| Auditoria de dependências | **0 vulnerabilidades reportadas** (`npm audit`) |
| axe-core, 9 estados por dispositivo | **0 violações A/AA testáveis**; itens de contraste sobre imagem/SVG ficam como revisão manual |
| Overflow horizontal | **Não observado** em 320, 390, 768, 1024 e 1440 px |
| Imagens quebradas / erros de console no build auditado | **0 / 0** |
| Compressão Brotli em produção | **Confirmada**, com `Vary: Accept-Encoding` |
| Publicação, indexação e entrega real de e-mail | **Não realizadas**; dependem de configuração oficial |

Os números acima são resultados de execução local, não promessas de desempenho, segurança absoluta, conformidade certificada ou posicionamento em buscadores.

## Desempenho medido localmente

Build de produção servido pelo servidor Node.js incluído, Chromium headless, fontes e assets locais. Não é Lighthouse nem dado de campo.

| Ambiente | Condição | LCP | CLS | Transferência inicial |
|---|---|---:|---:|---:|
| Desktop 1440 × 1000 | Sem throttling artificial | **0,124 s** | **0** | **147,0 KiB** |
| Mobile 390 × 844 | CPU 4×; rede simulada 1,6 Mbps down / 750 kbps up; latência 100 ms | **1,064 s** | **0** | **126,3 KiB** |

O LCP observado foi o texto do hero. A transferência inicial soma o documento e os recursos registrados até a estabilização da primeira carga. INP de campo, TTFB em produção e desempenho em aparelhos reais não foram medidos.

Evidência estruturada: [`tests/audit.json`](./tests/audit.json). Reproduzir com `npm run audit:local`.

## Funcional

- Navegação por âncoras, header com estado de rolagem e menu móvel com Escape, foco contido e retorno ao acionador.
- Carrossel: setas, indicadores, teclado, gesto horizontal. No mobile, o teste usa eventos de toque do Chromium; no desktop, eventos de pointer simulados. Slides inativos ficam `inert` e `aria-hidden`.
- Quatro conceitos abrem em diálogo e devolvem o foco ao fechar.
- Catálogos: busca, categorias, ordenação, detalhes, variantes e consulta demonstrativa. O fluxo de catálogo não é apresentado como loja com pagamento.
- Dashboard: período, alternância barras/linha, tabela equivalente de dados, busca, filtro, detalhes, alteração local de status, estoque ilustrativo e exportação CSV.
- Página comercial: navegação interna, serviços e chamada institucional fictícia.
- Laboratório: três abas acessíveis por teclado.
- Serviços: possibilidades expansíveis e CTAs que pré-selecionam o tipo de projeto no briefing.
- FAQs: abertura/fechamento nativo e comportamento de um item por vez.
- Formulário demonstrativo: valida sem transmitir nem confirmar envio.
- Formulário configurado: estados de carregamento, falha e sucesso exercitados com respostas controladas; sucesso depende de `ok` retornado pelo servidor.
- Privacidade em diálogo e página própria; 404 com status HTTP real no servidor Node.js.
- Hospedagem estática sem API: verificada separadamente; permanece em “Formulário demonstrativo / Validar briefing”, inclusive na página de privacidade.

## Conteúdo e links

- Grafia **Orvex Systems** preservada em marca, metadados, páginas e materiais.
- Projetos, empresas, produtos, indicadores e fluxos identificados como demonstrativos/fictícios.
- Sem clientes, depoimentos, métricas comerciais, equipe, endereço, CNPJ, prêmios ou certificações inventados.
- Sem número de WhatsApp, e-mail ou rede social fictícios. Canais ausentes exibem estado de configuração e não geram links inválidos.
- Âncoras locais e recursos referenciados verificados; nenhuma imagem quebrada nos estados auditados.
- Revisão de português e espaçamento em títulos, textos responsivos, mensagens de erro e estados do formulário.

## Acessibilidade

Automatizado com axe-core nas tags WCAG 2 A/AA, 2.1 A/AA e 2.2 AA, em desktop e mobile: página principal, três abas do laboratório, quatro conceitos e diálogo de privacidade.

- **0 violações detectadas** nos estados auditados.
- Itens `color-contrast` classificados como incompletos pelo axe em textos sobre imagens, gradientes ou SVG foram revisados por cálculo das cores principais e inspeção visual. Isso não substitui auditoria manual completa em todos os navegadores/tecnologias assistivas.
- Foco de diálogos/menu, retorno de foco, navegação por teclado do carrossel e das abas, rótulos de formulário e movimento reduzido foram exercitados.
- Leitor de tela real, ampliação extrema, todos os navegadores e certificação WCAG **não** foram realizados.

Contrastes calculados para pares representativos:

| Par | Razão aproximada |
|---|---:|
| Texto principal `#F3F5F8` sobre `#090B10` | 18,02:1 |
| Texto secundário `#9299A7` sobre `#090B10` | 6,88:1 |
| Texto auxiliar `#737D90` sobre `#090B10` | 4,75:1 |
| Branco sobre vermelho de CTA `#E32636` | 4,57:1 |
| Azul `#1769FF` sobre branco | 4,67:1 |
| Texto de demo `#627086` sobre `#F3F6FA` | 4,63:1 |
| Texto de gráfico `#8190A6` sobre `#111A28` | 5,38:1 |

## Segurança e privacidade verificadas

- Configuração pública não expõe segredos.
- Envio real bloqueado sem SMTP completo e identificação de privacidade.
- Validação no servidor, limite de payload, JSON-only, origem cruzada, honeypot e tempo mínimo.
- Rate limit, bloqueio de duplicidade/concorrência por identificador e exigência de aceitação do transporte.
- Falha do transporte não retorna sucesso.
- Arquivos privados não são servidos; 404 real; headers de segurança sem bloquear o preview incorporado.
- Turnstile: exigência de token quando configurado foi testada; validação externa com a Cloudflare não foi executada.

**Limite operacional:** rate limit e deduplicação são em memória de uma instância. Produção com múltiplas réplicas exige controle compartilhado e/ou proteção no proxy. Não há garantia transacional de exatamente-uma-vez com SMTP.

## SEO e publicação

- Metadados, Open Graph/Twitter card, favicon e imagem 1200 × 630 presentes.
- Sem domínio oficial, o servidor mantém `noindex` e robots restritivo. O build avisa a ausência de canonical/sitemap públicos.
- Com domínio configurado, o servidor gera robots/sitemap; o build insere canonical, OG URL e JSON-LD. Essa etapa deve ser repetida e conferida no domínio final.
- Não houve publicação, rastreamento por buscador, indexação ou teste de compartilhamento em rede social real.

## Pendências externas antes de produção

1. Confirmar domínio, WhatsApp, e-mail, redes sociais e controlador de dados.
2. Configurar SMTP e testar recebimento real na caixa oficial, incluindo spam e resposta.
3. Revisar política de privacidade, fornecedores, retenção e canal de solicitação de direitos.
4. Opcionalmente ativar Turnstile com chaves reais.
5. Refazer build com `PUBLIC_SITE_URL`, publicar em HTTPS e configurar 404/monitoramento.
6. Repetir testes no ambiente publicado e medir desempenho de campo.

## Evidências visuais

Capturas finais em `tests/screenshots/`, incluindo hero desktop/mobile, serviços, portfólio, laboratório, dashboard, formulário mobile e conceito industrial. A imagem da poltrona é original gerada para o conceito; não representa cliente ou projeto executado para terceiro.
