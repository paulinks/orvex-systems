# Orvex Systems

Portfólio institucional premium, responsivo e interativo. Implementação completa para avaliação local, com backend preparável para recebimento real de briefings.

**Estado da entrega:** site funcional em ambiente de demonstração. Não foi publicado em domínio oficial. WhatsApp, e-mail comercial, redes sociais, domínio e credenciais SMTP não foram fornecidos e não foram inventados.

## Começar

Requisito: **Node.js 20.19 ou superior** e npm.

```bash
cd orvex-systems
npm ci
npm run dev
```

Abrir `http://localhost:3000`. O servidor escuta em `0.0.0.0` para compatibilidade com ambientes de preview. A porta pode ser alterada em `.env`.

Não é necessário abrir `index.html` diretamente: módulos JavaScript, configuração pública e formulário precisam de um servidor HTTP.

### Build de produção

```bash
npm run build
npm run start:production
```

No Windows PowerShell:

```powershell
npm run build
$env:ORVEX_STATIC_DIR = "build"
npm start
```

O build gera `build/`, minifica JavaScript e CSS, cria versões gzip/Brotli e verifica os recursos locais referenciados no HTML. O servidor negocia a compressão conforme o navegador. O diretório é gerado e pode ser recriado a partir dos fontes.

**Para envio real, use o servidor Node.js incluído ou adapte as duas rotas de API ao seu provedor.** Uma hospedagem exclusivamente estática não envia e-mails. Nesse caso, a ausência de `/api/config` mantém o formulário explicitamente demonstrativo.

## O que foi implementado

- Header com estado de rolagem, navegação por seções e menu móvel acessível.
- Hero com composição original de navegador, produto e módulo visual.
- Faixa de especialidades sem movimento contínuo obrigatório.
- Quatro áreas de serviços, possibilidades expansíveis e CTAs que pré-selecionam o briefing.
- Carrossel com quatro projetos, setas, indicadores, teclado, gesto horizontal e slides inativos inertes. Sem autoplay.
- **Orvex Commerce:** catálogo de objetos fictícios, busca, categorias, ordenação, detalhes, variantes e consulta demonstrativa.
- **Orvex Business:** painel com dados fictícios, períodos, gráficos em barras/linha, tabela equivalente, busca, filtros, detalhes, alteração local de status, estoque ilustrativo e exportação CSV.
- **Orvex Corporate:** navegação interna, serviços, apresentação e chamada institucional de uma empresa fictícia.
- **Orvex Industrial:** catálogo técnico, busca por código, categorias, filtro de disponibilidade fictícia, especificações, quantidade e consulta.
- Laboratório com catálogo, dashboard e página comercial funcionais.
- Processo em cinco etapas, quatro pilares, apresentação institucional, nove perguntas frequentes e chamada final.
- Formulário com validação compartilhada entre navegador e servidor, erros por campo, estados de processamento, privacidade e proteção contra abuso.
- Política de privacidade em diálogo e página própria; página 404 com status HTTP correto.
- Metadados sociais, cartão de compartilhamento, favicon, fontes locais, imagens responsivas e identidade vetorial exclusiva.
- Ano do rodapé atualizado pelo navegador.

Todos os projetos são **conceitos demonstrativos**. Forma, Vértice, Axis e Nexos são marcas de exemplo. Não representam clientes, contratos, parceiros, depoimentos ou resultados da Orvex Systems.

## Formulário: modos e garantias

### Demonstração — estado atual

Sem configuração completa, a interface mostra **“Formulário demonstrativo”** e o botão **“Validar briefing”**. A validação acontece no navegador. Nenhum dado do briefing é transmitido ou armazenado. A mensagem final confirma apenas a validação, nunca um envio.

O backend também bloqueia envios reais enquanto a configuração estiver incompleta, mesmo que alguém chame a API diretamente.

### Envio real — após configuração

Com SMTP e identificação de privacidade válidos, a interface mostra **“Canal de recebimento configurado”** e **“Enviar solicitação”**. O navegador envia um JSON para `POST /api/inquiries`.

A resposta de sucesso só é exibida depois de o transporte SMTP aceitar a mensagem. Isso confirma aceitação pelo serviço, **não entrega garantida na caixa de entrada, leitura ou resposta comercial**.

Não há banco de dados. Os briefings são encaminhados por e-mail. O servidor não grava o conteúdo em arquivos e não registra o corpo das solicitações nos logs.

### Falha de configuração ou conexão

Se a configuração não puder ser verificada por falha de rede ou resposta inesperada, o envio fica desabilitado. Uma hospedagem estática com resposta 404 para a API é identificada como demonstração. O site não tenta enviar dados a um endpoint de terceiros não configurado.

### Proteção implementada

- Validação de tipos, tamanhos, opções permitidas e autorização de tratamento.
- Limite de corpo JSON de 20 KB.
- Verificação de origem e bloqueio de chamadas cross-site pelo navegador.
- Campo-armadilha e intervalo mínimo de 2,5 segundos antes do envio.
- Limite padrão de cinco tentativas por IP a cada 15 minutos.
- Identificador por solicitação, bloqueio de processamento concorrente e duplicidade por 24 horas.
- Indicação de processamento e bloqueio de controles durante a requisição.
- SMTP com TLS e validação normal de certificado; segredos exclusivamente no servidor.
- Cloudflare Turnstile opcional, carregado somente após a ação de envio.

**Limites importantes:** os controles de tentativas e duplicidade ficam em memória de uma instância. Reiniciar o servidor os apaga. Em múltiplas instâncias, use armazenamento compartilhado e/ou rate limiting no proxy. A prevenção de duplicidade é uma proteção operacional, não uma transação exatamente-uma-vez com o provedor de e-mail. Se a conexão cair após o SMTP aceitar uma mensagem, uma nova tentativa pode produzir outro e-mail.

`TRUST_PROXY=true` só deve ser usado atrás de um proxy confiável que sobrescreva `X-Forwarded-For`. Caso contrário, mantenha desativado.

## Configuração

Copie o modelo, sem versionar o arquivo preenchido:

```bash
cp .env.example .env
```

O servidor carrega `.env` automaticamente. Variáveis já definidas no ambiente têm precedência.

| Variável | Finalidade |
|---|---|
| `PORT`, `HOST` | Porta e interface do servidor. Padrão: 3000 e 0.0.0.0. |
| `PUBLIC_SITE_URL` | URL pública HTTPS, sem caminho ou barra final. Habilita canonical, sitemap e metadados absolutos no build. |
| `WHATSAPP_NUMBER` | Número oficial confirmado: código do país + DDD + número, somente dígitos. |
| `CONTACT_EMAIL` | E-mail comercial confirmado. |
| `INSTAGRAM_URL`, `LINKEDIN_URL` | URLs HTTPS oficiais desses perfis. Outros domínios são ignorados. |
| `SMTP_HOST`, `SMTP_PORT` | Servidor e porta SMTP do provedor contratado. |
| `SMTP_SECURE` | `true` para TLS implícito, normalmente porta 465; `false` para STARTTLS, normalmente 587. |
| `SMTP_USER`, `SMTP_PASS` | Credenciais SMTP. Nunca colocar no JavaScript público. |
| `MAIL_FROM` | Remetente autorizado pelo provedor. |
| `MAIL_TO` | Caixa comercial que receberá os briefings. |
| `PRIVACY_CONTROLLER` | Identificação real do controlador dos dados. |
| `PRIVACY_EMAIL` | Canal real para solicitações de privacidade. |
| `TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY` | Par de chaves opcional. Ambos são necessários para ativar. |
| `TRUST_PROXY` | `true` somente atrás de proxy confiável que sanitize o IP encaminhado. |
| `ORVEX_STATIC_DIR` | `build` para servir a versão compilada. O script de produção já define esse valor. |

O envio real exige host, usuário, senha, remetente, destinatário, porta válida e os dois campos de privacidade. Configuração parcial não habilita o recebimento.

### WhatsApp

Nenhum número de exemplo foi inserido. Enquanto não houver número oficial, o botão abre uma explicação e direciona ao formulário, sem criar link `wa.me` inválido.

Com `WHATSAPP_NUMBER` configurado, os botões se tornam links reais para `https://wa.me/NUMERO`, com mensagem inicial contextualizada e abertura em nova aba. Funcionam em celulares e computadores com acesso ao WhatsApp.

### Turnstile

Crie um widget no serviço da Cloudflare e configure as duas chaves. A implementação usa renderização explícita, ação `briefing` e verificação no servidor. Com domínio público configurado, o hostname também é verificado. A política de conteúdo permite o serviço apenas quando ele está ativado.

Revise o aviso de privacidade e as condições do provedor antes de ativar em produção.

### SMTP e entrega

- Use uma conta de serviço e credenciais com o menor privilégio necessário.
- Configure SPF, DKIM e DMARC no domínio remetente conforme o provedor.
- Não desative a validação de certificados TLS.
- Faça um envio de teste para a caixa oficial e confira recebimento, spam e resposta.
- Quando o contato informado for e-mail, ele é usado como `Reply-To`. Telefone não é inserido em headers.
- O servidor não presume prazo de resposta nem disponibilidade comercial.

## Publicação

1. Confirmar domínio, número de WhatsApp, e-mail, perfis sociais e identificação do controlador.
2. Preencher as variáveis no ambiente seguro da hospedagem. Não enviar `.env` ao repositório.
3. Revisar a política de privacidade com os fornecedores, localizações de tratamento, retenção e canais reais.
4. Executar `npm ci`, testes e `npm run build` com `PUBLIC_SITE_URL` definido.
5. Publicar o servidor Node.js atrás de HTTPS. Para apenas apresentação estática, publicar `build/` e manter o formulário em demonstração.
6. Apontar o domínio e verificar certificado HTTPS.
7. Configurar a página 404 personalizada no hospedador. No servidor incluído, rotas inexistentes já retornam 404.
8. Confirmar `robots.txt`, `sitemap.xml`, canonical e imagem de compartilhamento no domínio final.
9. Testar o recebimento real e os links oficiais em celular e computador.
10. Monitorar erros, disponibilidade e entrega do provedor de e-mail.

Sem `PUBLIC_SITE_URL`, o servidor envia `X-Robots-Tag: noindex, nofollow` e `robots.txt` bloqueia rastreamento. Isso evita apresentar o preview como site oficial indexável. **Indexação, posicionamento em buscas e desempenho em produção não foram presumidos.**

Em hospedagem estática, não faça rewrite de `/api/*` para `index.html` com status 200: isso transforma uma API ausente em uma resposta inválida. O modo seguro nesse caso é desabilitar o envio, como a implementação já faz.

## Arquitetura

```text
index.html               Conteúdo institucional sem dependência de renderização JS
404.html                 Página de erro sem conteúdo comercial inventado
privacidade.html         Política em página própria
server.mjs               HTTP, arquivos públicos, configuração, validação e SMTP
css/
  styles.css             Identidade, layout, responsividade e movimento reduzido
  demos.css              Interfaces demonstrativas, adaptadas por container queries
  pages.css              Páginas de privacidade e erro
js/
  main.js                Inicialização e configuração pública
  ui.js                  Navegação, foco, diálogos, revelação e utilitários
  projects.js            Carrossel e abertura dos conceitos
  lab.js                 Abas acessíveis do laboratório
  demos.js               Catálogos, dashboard e página comercial
  form.js                Estados e validação do briefing
  validation.js          Regras compartilhadas entre cliente e servidor
  privacy.js             Estado e controlador na página de privacidade
assets/
  fonts/                 Fontes locais e licenças OFL
  images/                Produto original, ilustrações, favicon e cartão social
  brand/                 Assinaturas vetoriais e fonte editável do cartão social
scripts/
  build.mjs              Build, verificação de recursos e compressão
  create-assets.py       Ilustrações SVG originais
  create-brand.py        Logotipos com tipografia convertida em caminhos
  create-social.mjs      Cartão social PNG e HTML autocontido
tests/                   Testes de servidor, navegador e acessibilidade
.env.example             Modelo sem credenciais
```

Não há framework de UI obrigatório. Os componentes reutilizáveis usam módulos ES, HTML semântico e CSS com escopo. A única dependência de produção é Nodemailer, fixada no lockfile em versão sem vulnerabilidades conhecidas na auditoria realizada. esbuild e ferramentas de teste são dependências de desenvolvimento.

As fontes são carregadas localmente; não há Google Fonts, CDN, analytics ou pixel de rastreamento no funcionamento padrão. A imagem principal tem variante menor e `srcset`; as demais ilustrações são SVG. O conteúdo institucional permanece legível sem JavaScript.

## Identidade e assets

- Grafite principal: `#090B10`; superfície: `#11151D`.
- Vermelho de ação: `#E32636`; azul técnico: `#1769FF`.
- Branco gelo: `#F3F5F8`; texto secundário: `#9299A7`.
- Títulos: Space Grotesk. Texto: Inter. Ambas sob SIL Open Font License; licenças incluídas.
- Assinatura construída no X, com quatro módulos e um ponto vermelho controlado.
- Arquivos em `assets/brand/`: horizontal, compacta, monocromática branca e monocromática preta. O texto está em caminhos vetoriais, sem exigir fonte instalada.
- Favicon: `assets/images/orvex-mark.svg`.
- Compartilhamento: `assets/images/og-orvex.png`, 1200 × 630; fonte editável em `assets/brand/og-source.html`.
- Fotografia da poltrona: imagem original gerada para este conceito, não fotografia de cliente. Ilustrações de objetos, componentes e arquitetura: SVG originais desta entrega.

Preservar proporções e contraste da assinatura. Usar a versão monocromática quando a aplicação vermelha não tiver contraste adequado. Não adicionar efeitos luminosos como parte obrigatória da marca.

Para regenerar os assets gráficos, são necessários Python com FontTools e Brotli, além das dependências npm e do Chromium de teste:

```bash
python scripts/create-assets.py
python scripts/create-brand.py
node scripts/create-social.mjs
```

Esses passos não são necessários para rodar ou publicar: os assets finais já estão incluídos.

## Testes e revisão

```bash
npm test
npx playwright install --with-deps chromium
npm run test:e2e
npm run check
```

Os testes de navegador usam um servidor isolado na porta 3100 e limpam variáveis de integração para impedir envios reais acidentais. Estados de sucesso e falha do transporte são testados com respostas controladas; isso não equivale a validar uma conta SMTP externa.

Consultar **[QA.md](./QA.md)** para os resultados efetivamente obtidos, escopo e limitações. Nenhum resultado de Lighthouse, Core Web Vitals de campo, certificação WCAG ou auditoria jurídica é alegado sem medição específica.

## Antes de considerar a publicação concluída

- [ ] Domínio e HTTPS oficiais ativos.
- [ ] Contatos e redes sociais confirmados.
- [ ] SMTP testado com recebimento real na caixa oficial.
- [ ] Controlador, canal de privacidade, fornecedores e retenção documentados.
- [ ] Política de privacidade revisada para a operação real.
- [ ] Build refeito com o domínio definitivo.
- [ ] Testes repetidos no ambiente de produção.
- [ ] Backup, monitoramento e responsáveis por manutenção definidos.

**Orvex Systems — tecnologia, intenção e execução.**
