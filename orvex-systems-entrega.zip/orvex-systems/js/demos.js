import { icon, escapeHTML, showToast, copyText, downloadText, prefillBriefing } from './ui.js';

const furniture = [
  { id: 'f01', code: 'FM-001', name: 'Poltrona Serena', category: 'Poltronas', image: 'forma-chair.webp', material: 'Couro e madeira', variants: ['Nogueira', 'Carvalho natural'], description: 'Linhas acolhedoras, estrutura em madeira e um convite para desacelerar. Uma peça demonstrativa para explorar a experiência de descoberta de produto.', specs: 'Largura: 78 cm · Profundidade: 82 cm · Altura: 91 cm' },
  { id: 'f02', code: 'FM-002', name: 'Luminária Arco', category: 'Iluminação', image: 'lamp.svg', material: 'Linho e metal', variants: ['Areia', 'Grafite'], description: 'Uma silhueta equilibrada e luz difusa para compor ambientes com personalidade. Acabamentos selecionáveis nesta demonstração.', specs: 'Diâmetro: 38 cm · Altura: 54 cm · Soquete: E27' },
  { id: 'f03', code: 'FM-003', name: 'Mesa Lateral Tempo', category: 'Mesas', image: 'table.svg', material: 'Madeira maciça', variants: ['Nogueira', 'Carvalho natural'], description: 'Uma superfície simples, generosa em detalhes. Proporções pensadas para acompanhar poltronas e criar pequenos pontos de apoio.', specs: 'Diâmetro: 52 cm · Altura: 48 cm · Peso: 6 kg' },
  { id: 'f04', code: 'FM-004', name: 'Poltrona Estrutura', category: 'Poltronas', image: 'chair-frame.svg', material: 'Tecido e madeira', variants: ['Areia', 'Verde musgo'], description: 'Madeira aparente e estofado leve em uma composição de linhas honestas. Explore os acabamentos e adicione o item a uma consulta de exemplo.', specs: 'Largura: 72 cm · Profundidade: 80 cm · Altura: 86 cm' },
  { id: 'f05', code: 'FM-005', name: 'Luminária Ponto', category: 'Iluminação', image: 'lamp-desk.svg', material: 'Alumínio pintado', variants: ['Grafite', 'Off-white'], description: 'Formato compacto, presença marcante. Uma peça de apoio que demonstra como atributos e variantes podem organizar uma vitrine.', specs: 'Diâmetro: 28 cm · Altura: 36 cm · Peso: 1,8 kg' },
  { id: 'f06', code: 'FM-006', name: 'Banco Origem', category: 'Mesas', image: 'bench.svg', material: 'Madeira maciça', variants: ['Carvalho natural', 'Nogueira'], description: 'Um desenho versátil, entre banco e apoio lateral.Materialidade e função em uma peça criada exclusivamente para este catálogo fictício.', specs: 'Largura: 84 cm · Profundidade: 32 cm · Altura: 42 cm' }
];
const industrial = [
  { id: 'i01', code: 'RL-6204', name: 'Rolamento de esferas', category: 'Rolamentos', image: 'bearing.svg', material: 'Aço cromado', variants: ['Vedação 2RS', 'Vedação ZZ'], available: true, description: 'Componente ilustrativo para aplicações de transmissão e suporte de eixos. Especificações fictícias, apresentadas para demonstrar uma consulta técnica.', specs: 'Diâmetro interno: 20 mm · Externo: 47 mm · Largura: 14 mm' },
  { id: 'i02', code: 'VL-0200', name: 'Válvula de esfera', category: 'Válvulas', image: 'valve.svg', material: 'Latão niquelado', variants: ['Conexão 1/2 pol.', 'Conexão 3/4 pol.'], available: true, description: 'Exemplo de produto em um catálogo B2B, com informações técnicas organizadas e consulta por item. Não representa estoque ou oferta comercial real.', specs: 'Pressão ilustrativa: 150 PSI · Acionamento: manual · Conexão: rosqueada' },
  { id: 'i03', code: 'SN-0180', name: 'Sensor indutivo', category: 'Sensores', image: 'sensor.svg', material: 'Corpo metálico', variants: ['NPN · NA', 'PNP · NA'], available: false, description: 'Interface de referência para apresentar atributos técnicos, disponibilidade ilustrativa e seleção de configuração antes de uma consulta.', specs: 'Distância de detecção: 8 mm · Alimentação: 24 Vcc · Grau de proteção: IP67' },
  { id: 'i04', code: 'MT-0075', name: 'Motor elétrico 0,75 cv', category: 'Motores', image: 'motor.svg', material: 'Carcaça de alumínio', variants: ['Monofásico', 'Trifásico'], available: true, description: 'Produto demonstrativo para explorar busca por código, categorias e montagem de uma lista de itens para orçamento.', specs: 'Potência: 0,75 cv · Rotação: 1.720 rpm · Carcaça: 80' }
];
const normalize = value => String(value).normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase();
const money = value => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(value);
let instance = 0;

function mountCatalog(root, kind, context) {
  const industrialMode = kind === 'industrial', products = industrialMode ? industrial : furniture;
  const uid = `catalog-${++instance}`;
  const state = { category: 'Todos', query: '', sort: 'featured', available: false, view: 'catalog', productId: null, variant: '', quantity: 1, selection: new Map(), note: '', summary: '' };
  const categories = ['Todos', ...new Set(products.map(p => p.category))];
  root.innerHTML = `<div class="demo demo-catalog ${industrialMode ? 'demo-industrial' : ''}" data-demo="${kind}"><div class="demo-store-header"><div class="demo-wordmark">${industrialMode ? 'AXIS<span> / SUPRIMENTOS</span>' : 'forma<sup>®</sup>'}<small>${industrialMode ? 'CATÁLOGO TÉCNICO DEMONSTRATIVO' : 'OBJETOS COM PROPÓSITO'}</small></div><button type="button" class="demo-quote-button" data-action="quote">${icon('cart')}<span>Consulta</span><b data-quote-count>0</b></button></div><div class="demo-catalog-content"></div><div class="demo-bottom-note">${icon('info')}<span>${industrialMode ? 'Produtos, códigos e especificações fictícios. Nenhuma solicitação comercial é enviada.' : 'Coleção fictícia. Imagens ilustrativas. Sua consulta é apenas uma demonstração, sem compra ou pagamento.'}</span></div></div>`;
  const content = root.querySelector('.demo-catalog-content');
  const updateCount = () => { root.querySelector('[data-quote-count]').textContent = [...state.selection.values()].reduce((sum, item) => sum + item.quantity, 0); };
  const filtered = () => {
    let result = products.filter(p => (state.category === 'Todos' || p.category === state.category) && (!state.available || p.available) && normalize(`${p.name} ${p.code} ${p.category} ${p.material}`).includes(normalize(state.query)));
    if (state.sort === 'name') result = [...result].sort((a,b) => a.name.localeCompare(b.name, 'pt-BR'));
    if (state.sort === 'code') result = [...result].sort((a,b) => a.code.localeCompare(b.code));
    return result;
  };
  function productCard(p) {
    return `<article class="demo-product-card"><button type="button" class="demo-product-image" data-product="${p.id}" aria-label="Ver detalhes de ${escapeHTML(p.name)}"><img src="/assets/images/${p.image}" width="240" height="200" alt="${escapeHTML(p.name)} — imagem demonstrativa" loading="lazy"></button><div class="demo-product-info"><span class="demo-product-code">${p.code} · ${p.category}</span><h4>${p.name}</h4><div class="demo-product-meta"><span>${industrialMode ? (p.available ? 'Em estoque · fictício' : 'Sob encomenda · fictício') : p.material}</span><button type="button" data-product="${p.id}" aria-label="${industrialMode ? 'Ver especificações' : 'Ver detalhes'} de ${escapeHTML(p.name)}">${icon('up-right')}</button></div></div></article>`;
  }
  function renderCatalog(focusSelector) {
    state.view = 'catalog';
    const result = filtered();
    content.innerHTML = `<div class="demo-catalog-intro"><div><p class="demo-kicker">${industrialMode ? 'COMPONENTES PARA A SUA OPERAÇÃO' : 'COLEÇÃO / OBJETOS DE DESIGN'}</p><h3 data-focus-heading tabindex="-1">${industrialMode ? 'A peça certa, sem rodeios.' : 'Encontre a sua forma.'}</h3></div><span class="demo-collection-count">${products.length} ${industrialMode ? 'componentes' : 'objetos'}<br> 100% demonstrativo</span></div><div class="demo-filter-row"><div class="demo-search">${icon('search')}<label class="sr-only" for="${uid}-search">Buscar no catálogo</label><input id="${uid}-search" type="search" placeholder="${industrialMode ? 'Buscar produto ou código…' : 'Buscar um objeto…'}" value="${escapeHTML(state.query)}" data-catalog-search autocomplete="off"></div><label class="demo-sort-label">Ordenar<select data-catalog-sort aria-label="Ordenar catálogo"><option value="featured" ${state.sort === 'featured' ? 'selected' : ''}>Destaques</option><option value="name" ${state.sort === 'name' ? 'selected' : ''}>Nome A–Z</option><option value="code" ${state.sort === 'code' ? 'selected' : ''}>Código</option></select></label></div><div class="demo-category-row"><div class="demo-chips" role="group" aria-label="Categorias do catálogo">${categories.map(c => `<button type="button" data-category="${c}" aria-pressed="${state.category === c}">${c}</button>`).join('')}</div>${industrialMode ? '<label class="demo-check"><input type="checkbox" data-available '+(state.available?'checked':'')+'> Só estoque fictício</label>' : ''}</div><div class="demo-results-meta"><span data-results-count role="status" aria-live="polite">${result.length} ${result.length === 1 ? 'item encontrado' : 'itens encontrados'}</span><span>Selecione um item para explorar ${icon('down')}</span></div><div class="demo-product-grid">${result.length ? result.map(productCard).join('') : `<div class="demo-empty">${icon('search')}<h4>Nenhum item por aqui.</h4><p>Tente outro termo ou uma combinação diferente de filtros.</p><button type="button" class="demo-button secondary" data-action="reset-filters">Limpar filtros</button></div>`}</div>`;
    if (focusSelector) content.querySelector(focusSelector)?.focus({ preventScroll: true });
  }
  function updateResults() {
    const result = filtered();
    content.querySelector('.demo-product-grid').innerHTML = result.length ? result.map(productCard).join('') : `<div class="demo-empty">${icon('search')}<h4>Nenhum item por aqui.</h4><p>Tente outro termo ou uma combinação diferente de filtros.</p><button type="button" class="demo-button secondary" data-action="reset-filters">Limpar filtros</button></div>`;
    content.querySelector('[data-results-count]').textContent = `${result.length} ${result.length === 1 ? 'item encontrado' : 'itens encontrados'}`;
  }
  function renderDetail() {
    const p = products.find(product => product.id === state.productId); if (!p) return renderCatalog();
    state.view = 'detail'; state.variant = p.variants[0]; state.quantity = 1;
    content.innerHTML = `<button type="button" class="demo-back" data-action="back">${icon('left')} Voltar ao catálogo</button><div class="demo-product-detail"><div class="demo-detail-image"><img src="/assets/images/${p.image}" width="480" height="400" alt="${escapeHTML(p.name)} — produto fictício"><span>IMAGEM ILUSTRATIVA · CONCEITO</span></div><div class="demo-detail-copy"><p class="demo-kicker">${p.code} / ${p.category}</p><h3 data-focus-heading tabindex="-1">${p.name}</h3><p>${p.description}</p><div class="demo-specs"><strong>Especificações de exemplo</strong><span>${p.specs}</span></div><div class="demo-variants"><span>${industrialMode ? 'Configuração' : 'Acabamento de referência'}: <b data-variant-label>${state.variant}</b></span><div>${p.variants.map((v,i) => `<button type="button" data-variant="${escapeHTML(v)}" aria-pressed="${i === 0}">${v}</button>`).join('')}</div></div>${industrialMode ? `<div class="demo-quantity-row"><span>Quantidade</span><div class="demo-stepper"><button type="button" data-quantity="-1" aria-label="Diminuir quantidade">${icon('minus')}</button><input type="number" min="1" max="99" value="1" data-quantity-input aria-label="Quantidade demonstrativa"><button type="button" data-quantity="1" aria-label="Aumentar quantidade">${icon('plus')}</button></div></div>` : ''}<button type="button" class="demo-button" data-action="add">${icon('cart')} Adicionar à consulta</button><small class="demo-detail-disclaimer">Consulta demonstrativa. Sem preço, pedido, pagamento ou envio real.</small></div></div>`;
    content.querySelector('[data-focus-heading]').focus({ preventScroll: true });
  }
  function renderQuote() {
    state.view = 'quote';
    const entries = [...state.selection.entries()];
    content.innerHTML = `<button type="button" class="demo-back" data-action="back">${icon('left')} Continuar explorando</button><div class="demo-catalog-intro"><div><p class="demo-kicker">SEU RESUMO DE INTERESSE</p><h3 data-focus-heading tabindex="-1">Uma consulta, do seu jeito.</h3></div></div>${entries.length ? `<div class="demo-quote-list">${entries.map(([key,item]) => { const p = products.find(p => p.id === item.id); return `<div class="demo-quote-item"><img src="/assets/images/${p.image}" width="64" height="64" alt="${escapeHTML(p.name)}"><div><strong>${p.name}</strong><span>${p.code} · ${escapeHTML(item.variant)} · Quantidade: ${item.quantity}</span></div><button type="button" data-remove="${escapeHTML(key)}" aria-label="Remover ${escapeHTML(p.name)} da consulta">${icon('close')}</button></div>`; }).join('')}</div><div class="demo-quote-total"><span>${entries.length} ${entries.length === 1 ? 'produto selecionado' : 'produtos selecionados'}</span><strong>Valores e disponibilidade a avaliar</strong></div><label class="demo-label" for="${uid}-note">Observação para o resumo <small>opcional</small></label><textarea class="demo-textarea" id="${uid}-note" data-quote-note rows="2" maxlength="1000" placeholder="Alguma preferência ou contexto?">${escapeHTML(state.note)}</textarea><button type="button" class="demo-button" data-action="prepare">${icon('layers')} Preparar resumo demonstrativo</button><div data-summary-region></div>` : `<div class="demo-empty">${icon('cart')}<h4>Sua consulta começa com uma escolha.</h4><p>Explore os produtos e adicione itens para montar um resumo de exemplo.</p><button type="button" class="demo-button" data-action="back">Explorar catálogo ${icon('arrow')}</button></div>`}`;
    content.querySelector('[data-focus-heading]').focus({ preventScroll: true });
  }
  function prepareSummary() {
    const lines = [`Consulta demonstrativa — Orvex ${industrialMode ? 'Industrial' : 'Commerce'}`, 'Gostaria de avaliar um catálogo com uma experiência semelhante.', '', 'Itens fictícios selecionados:', ...[...state.selection.values()].map(item => { const p = products.find(p => p.id === item.id); return `• ${item.quantity}× ${p.name} (${p.code}) — ${item.variant}`; }), ...(state.note.trim() ? ['', `Observação: ${state.note.trim()}`] : []), '', 'Resumo de interesse apenas. Nenhum pedido, pagamento ou solicitação foi enviado.'];
    state.summary = lines.join('\n');
    const region = content.querySelector('[data-summary-region]');
    region.innerHTML = `<div class="demo-summary"><label class="demo-label" for="${uid}-summary">Resumo preparado — ainda não enviado</label><textarea id="${uid}-summary" class="demo-textarea" rows="9" readonly data-summary-text>${escapeHTML(state.summary)}</textarea><div class="demo-summary-actions"><button type="button" class="demo-button secondary" data-action="copy">${icon('copy')} Copiar resumo</button><button type="button" class="demo-button" data-action="use-briefing">Usar no briefing ${icon('up-right')}</button></div><p>Nenhum dado foi transmitido. Você poderá revisar o texto no formulário da Orvex Systems.</p></div>`;
    region.querySelector('[data-focus-heading]')?.focus();
    region.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
  root.addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button || !root.contains(button)) return;
    if (button.dataset.category) { state.category = button.dataset.category; content.querySelectorAll('[data-category]').forEach(el => el.setAttribute('aria-pressed', String(el === button))); updateResults(); }
    if (button.dataset.product) { state.productId = button.dataset.product; renderDetail(); }
    if (button.dataset.variant) { state.variant = button.dataset.variant; content.querySelector('[data-variant-label]').textContent = state.variant; content.querySelectorAll('[data-variant]').forEach(el => el.setAttribute('aria-pressed', String(el === button))); }
    if (button.dataset.quantity) { state.quantity = Math.max(1, Math.min(99, state.quantity + Number(button.dataset.quantity))); content.querySelector('[data-quantity-input]').value = state.quantity; }
    if (button.dataset.remove) { state.selection.delete(button.dataset.remove); state.summary = ''; updateCount(); renderQuote(); }
    const action = button.dataset.action;
    if (action === 'back') renderCatalog();
    if (action === 'quote') renderQuote();
    if (action === 'reset-filters') { state.query = ''; state.category = 'Todos'; state.available = false; state.sort = 'featured'; renderCatalog('[data-catalog-search]'); }
    if (action === 'add') {
      const key = `${state.productId}::${state.variant}`, existing = state.selection.get(key);
      state.selection.set(key, { id: state.productId, variant: state.variant, quantity: Math.min(99, (existing?.quantity || 0) + state.quantity) }); state.summary = ''; updateCount();
      button.innerHTML = `${icon('check')} Adicionado à consulta`; showToast('Item adicionado à consulta demonstrativa. Nenhuma operação real foi realizada.');
      context.later(() => { if (button.isConnected) button.innerHTML = `${icon('cart')} Adicionar à consulta`; }, 1800);
    }
    if (action === 'prepare') prepareSummary();
    if (action === 'copy') context.later(async () => { const copied = await copyText(state.summary, content.querySelector('[data-summary-text]')); showToast(copied ? 'Resumo copiado. Nenhum dado foi enviado.' : 'Não foi possível copiar automaticamente. O texto está selecionado para cópia manual.'); }, 0);
    if (action === 'use-briefing') { if (!state.summary) prepareSummary(); prefillBriefing('Catálogo digital', state.summary); }
  }, { signal: context.signal });
  root.addEventListener('input', event => {
    if (event.target.matches('[data-catalog-search]')) { state.query = event.target.value; updateResults(); }
    if (event.target.matches('[data-quote-note]')) { state.note = event.target.value; state.summary = ''; }
    if (event.target.matches('[data-quantity-input]')) { state.quantity = Math.max(1, Math.min(99, Math.floor(Number(event.target.value) || 1))); }
  }, { signal: context.signal });
  root.addEventListener('change', event => {
    if (event.target.matches('[data-catalog-sort]')) { state.sort = event.target.value; updateResults(); }
    if (event.target.matches('[data-available]')) { state.available = event.target.checked; updateResults(); }
    if (event.target.matches('[data-quantity-input]')) event.target.value = state.quantity;
  }, { signal: context.signal });
  renderCatalog();
}

const originalOrders = [
  { id: '1048', client: 'Cliente 001', product: 'Poltrona Serena', value: 1890, status: 'Em preparo', day: 30 },
  { id: '1047', client: 'Cliente 002', product: 'Luminária Arco', value: 480, status: 'Concluído', day: 29 },
  { id: '1046', client: 'Cliente 003', product: 'Mesa Lateral Tempo', value: 760, status: 'Pendente', day: 28 },
  { id: '1045', client: 'Cliente 004', product: 'Poltrona Estrutura', value: 1590, status: 'Concluído', day: 26 },
  { id: '1044', client: 'Cliente 005', product: 'Luminária Ponto', value: 390, status: 'Em preparo', day: 23 },
  { id: '1043', client: 'Cliente 006', product: 'Banco Origem', value: 680, status: 'Concluído', day: 18 },
  { id: '1042', client: 'Cliente 007', product: 'Poltrona Serena', value: 1890, status: 'Pendente', day: 12 },
  { id: '1041', client: 'Cliente 008', product: 'Mesa Lateral Tempo', value: 760, status: 'Concluído', day: 5 }
];
const orderStatuses = ['Pendente','Em preparo','Concluído'];
function mountDashboard(root, context) {
  const uid = `dashboard-${++instance}`;
  const state = { view: 'overview', period: '30', chart: 'bars', query: '', status: 'Todos', selectedOrder: null, orders: originalOrders.map(o => ({ ...o })), stock: Object.fromEntries(furniture.map((p,i) => [p.id, [12,8,6,9,14,4][i]])) };
  root.innerHTML = `<div class="demo demo-dashboard" data-demo="business"><aside class="demo-dashboard-sidebar"><div class="demo-wordmark">${icon('layers')} nexos<small>VISÃO DE NEGÓCIO</small></div><nav aria-label="Telas do dashboard"><button type="button" data-dashboard-view="overview" aria-pressed="true">${icon('grid')}<span>Visão geral</span></button><button type="button" data-dashboard-view="orders" aria-pressed="false">${icon('cart')}<span>Pedidos</span></button><button type="button" data-dashboard-view="products" aria-pressed="false">${icon('layers')}<span>Produtos</span></button></nav><div class="demo-sidebar-note"><span class="demo-dot"></span> AMBIENTE DEMO<small>Sem autenticação.<br> Sem dados reais.</small></div></aside><div class="demo-dashboard-main"><div class="demo-dashboard-top"><div><p class="demo-kicker">PAINEL ADMINISTRATIVO / CONCEITO</p><h3 data-dashboard-title>Operação em perspectiva.</h3></div><span class="demo-badge">DADOS FICTÍCIOS</span></div><div class="demo-dashboard-toolbar"><span>Outubro de 2026 · cenário ilustrativo</span><label>Período<select data-dashboard-period aria-label="Período dos dados fictícios"><option value="30">Últimos 30 dias</option><option value="7">Últimos 7 dias</option></select></label></div><div class="demo-dashboard-content"></div><div class="demo-dashboard-footer"><span>Interações locais. Nenhuma operação real.</span><button type="button" data-action="reset-dashboard">Reiniciar dados ${icon('arrow')}</button></div></div></div>`;
  const content = root.querySelector('.demo-dashboard-content');
  const periodOrders = () => state.orders.filter(o => state.period === '30' || o.day >= 25);
  const filteredOrders = () => periodOrders().filter(o => (state.status === 'Todos' || o.status === state.status) && normalize(`${o.id} ${o.client} ${o.product}`).includes(normalize(state.query)));
  function metrics() {
    const orders = periodOrders(), completed = orders.filter(o => o.status === 'Concluído').length;
    return `<div class="demo-metrics"><article><span>Pedidos fictícios</span><strong>${orders.length.toString().padStart(2,'0')}</strong><small>Registros de demonstração</small></article><article><span>Valor ilustrativo</span><strong>${money(orders.reduce((sum,o) => sum + o.value,0))}</strong><small>Não representa receita real</small></article><article><span>Conclusão no exemplo</span><strong>${orders.length ? Math.round(completed / orders.length * 100) : 0}%</strong><small>${completed} de ${orders.length} pedidos fictícios</small></article></div>`;
  }
  function chart() {
    const values = state.period === '7' ? [1,0,1,2,1,0,1] : [2,4,3,6,5,8,6,9,7,10,8,12];
    const labels = state.period === '7' ? ['25','26','27','28','29','30','31'] : ['01','03','06','08','11','13','16','18','21','23','26','30'];
    const max = Math.max(...values), points = values.map((v,i) => `${32 + i * (496/(values.length-1))},${142 - v/max*110}`);
    const svg = state.chart === 'bars' ? values.map((v,i) => { const step = 496/values.length, height = v/max*110; return `<rect x="${32+i*step+step*.18}" y="${142-height}" width="${step*.60}" height="${height}" rx="3" fill="${i === values.length-1 ? '#1769ff' : '#b6cefa'}"/>`; }).join('') : `<path d="M${points.join(' L')} L528 142 L32 142Z" fill="#1769ff" opacity=".07"/><polyline points="${points.join(' ')}" fill="none" stroke="#1769ff" stroke-width="3" stroke-linejoin="round"/>${points.map(p => `<circle cx="${p.split(',')[0]}" cy="${p.split(',')[1]}" r="3" fill="#1769ff"/>`).join('')}`;
    return `<section class="demo-chart-card"><div class="demo-card-heading"><div><h4>Volume de pedidos</h4><p>Uma leitura possível dos dados. Inteiramente fictícia.</p></div><div class="demo-view-toggle" role="group" aria-label="Visualização do gráfico"><button type="button" data-chart="bars" aria-pressed="${state.chart === 'bars'}">${icon('chart')} Barras</button><button type="button" data-chart="line" aria-pressed="${state.chart === 'line'}">${icon('link')} Linha</button></div></div><svg class="demo-chart-svg" viewBox="0 0 560 174" role="img" aria-label="Gráfico de pedidos fictícios, ${state.period} dias. Valores disponíveis na tabela abaixo."><path d="M32 32H532M32 87H532M32 142H532" stroke="#e3e9f2" stroke-dasharray="3 4"/><text x="6" y="36" fill="#63758c" font-size="9">${max}</text><text x="12" y="146" fill="#63758c" font-size="9">0</text>${svg}${labels.map((label,i) => `<text x="${state.chart === 'bars' ? 32+(i+.5)*(496/values.length) : 32+i*(496/(values.length-1))}" y="165" fill="#63758c" font-size="9" text-anchor="middle">${label}</text>`).join('')}</svg><details class="demo-chart-data"><summary>Ver dados do gráfico em tabela</summary><table><caption>Volume ilustrativo por dia de outubro</caption><thead><tr><th>Dia</th>${labels.map(l => `<th>${l}</th>`).join('')}</tr></thead><tbody><tr><th>Pedidos</th>${values.map(v => `<td>${v}</td>`).join('')}</tr></tbody></table></details></section>`;
  }
  function orderTable(orders, compact = false) {
    return `<div class="demo-table-scroll"><table class="demo-table"><caption class="sr-only">Pedidos fictícios para demonstração</caption><thead><tr><th scope="col">Pedido</th><th scope="col">Cliente fictício</th>${compact ? '' : '<th scope="col">Produto</th>'}<th scope="col">Valor ilustrativo</th><th scope="col">Status</th></tr></thead><tbody>${orders.length ? orders.map(o => `<tr><td><button type="button" data-order="${o.id}" aria-label="Ver pedido fictício ${o.id}">#${o.id} ${icon('up-right')}</button></td><td>${o.client}</td>${compact ? '' : `<td>${o.product}</td>`}<td>${money(o.value)}</td><td><span class="demo-status status-${orderStatuses.indexOf(o.status)}"><i></i>${o.status}</span></td></tr>`).join('') : '<tr><td colspan="5" class="demo-table-empty">Nenhum pedido corresponde aos filtros.</td></tr>'}</tbody></table></div>`;
  }
  function orderDetail() {
    const order = state.orders.find(o => o.id === state.selectedOrder); if (!order) return '';
    return `<section class="demo-order-detail" aria-labelledby="${uid}-order-title"><div><p class="demo-kicker">DETALHE DO REGISTRO FICTÍCIO</p><h4 id="${uid}-order-title" tabindex="-1">Pedido #${order.id}</h4><p>${order.client} · ${order.product} · ${money(order.value)}</p></div><div><label for="${uid}-status">Status demonstrativo</label><select id="${uid}-status" data-order-status>${orderStatuses.map(s => `<option ${s === order.status ? 'selected' : ''}>${s}</option>`).join('')}</select><button type="button" class="demo-button small" data-action="save-status">Atualizar demonstração ${icon('check')}</button></div></section>`;
  }
  function render() {
    root.querySelectorAll('[data-dashboard-view]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.dashboardView === state.view)));
    root.querySelector('[data-dashboard-title]').textContent = { overview: 'Operação em perspectiva.', orders: 'Cada pedido, uma visão clara.', products: 'Produtos em organização.' }[state.view];
    if (state.view === 'overview') content.innerHTML = `${metrics()}${chart()}<section class="demo-table-card"><div class="demo-card-heading"><div><h4>Pedidos recentes</h4><p>Abra um registro para interagir com o exemplo.</p></div><button type="button" class="demo-inline-button" data-dashboard-view="orders">Ver todos ${icon('arrow')}</button></div>${orderTable(periodOrders().slice(0,4),true)}${orderDetail()}</section>`;
    if (state.view === 'orders') content.innerHTML = `${metrics()}<section class="demo-table-card"><div class="demo-card-heading"><div><h4>Pedidos demonstrativos</h4><p>Pesquise, filtre e abra um registro.</p></div><button type="button" class="demo-inline-button" data-action="export">${icon('download')} Exportar CSV</button></div><div class="demo-orders-filters"><div class="demo-search">${icon('search')}<label class="sr-only" for="${uid}-order-search">Buscar pedido fictício</label><input id="${uid}-order-search" type="search" data-order-search placeholder="Pedido, cliente ou produto…" value="${escapeHTML(state.query)}"></div><label class="sr-only" for="${uid}-order-filter">Filtrar por status</label><select id="${uid}-order-filter" data-order-filter><option>Todos</option>${orderStatuses.map(s => `<option ${s === state.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div><div data-orders-table>${orderTable(filteredOrders())}</div><p class="demo-table-count" role="status">${filteredOrders().length} registros fictícios</p>${orderDetail()}</section>`;
    if (state.view === 'products') content.innerHTML = `${metrics()}<section class="demo-table-card"><div class="demo-card-heading"><div><h4>Catálogo e estoque fictício</h4><p>Ajuste as quantidades para testar a interface. Nada é salvo em um sistema real.</p></div></div><div class="demo-stock-list">${furniture.map(p => `<div class="demo-stock-item"><img src="/assets/images/${p.image}" width="56" height="56" alt="${p.name}"><div><strong>${p.name}</strong><span>${p.code} · ${p.category}</span></div><div class="demo-stepper"><button type="button" data-stock="${p.id}" data-delta="-1" aria-label="Diminuir estoque fictício de ${p.name}" ${state.stock[p.id] === 0 ? 'disabled' : ''}>−</button><output data-stock-value="${p.id}" aria-label="Estoque fictício de ${p.name}">${state.stock[p.id]}</output><button type="button" data-stock="${p.id}" data-delta="1" aria-label="Aumentar estoque fictício de ${p.name}" ${state.stock[p.id] === 999 ? 'disabled' : ''}>+</button></div></div>`).join('')}</div></section>`;
  }
  root.addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button || !root.contains(button)) return;
    if (button.dataset.dashboardView) { state.view = button.dataset.dashboardView; state.selectedOrder = null; render(); }
    if (button.dataset.chart) { state.chart = button.dataset.chart; render(); content.querySelector(`[data-chart="${state.chart}"]`)?.focus({ preventScroll: true }); }
    if (button.dataset.order) { state.selectedOrder = button.dataset.order; render(); content.querySelector('.demo-order-detail h4')?.focus({ preventScroll: true }); }
    if (button.dataset.stock) {
      const id = button.dataset.stock; state.stock[id] = Math.max(0,Math.min(999,state.stock[id]+Number(button.dataset.delta)));
      content.querySelector(`[data-stock-value="${id}"]`).textContent = state.stock[id];
      content.querySelectorAll(`[data-stock="${id}"]`).forEach(el => el.disabled = Number(el.dataset.delta) < 0 ? state.stock[id] === 0 : state.stock[id] === 999);
      showToast('Estoque alterado apenas nesta demonstração. Nenhum dado real foi atualizado.');
    }
    if (button.dataset.action === 'save-status') { const order = state.orders.find(o => o.id === state.selectedOrder), value = content.querySelector('[data-order-status]').value; if (order && orderStatuses.includes(value)) { order.status = value; render(); showToast('Status atualizado somente no cenário fictício.'); content.querySelector('.demo-order-detail h4')?.focus({ preventScroll: true }); } }
    if (button.dataset.action === 'export') {
      const rows = [['AMBIENTE DEMONSTRATIVO — DADOS FICTÍCIOS'],['Pedido','Cliente','Produto','Valor ilustrativo BRL','Status'],...filteredOrders().map(o => [o.id,o.client,o.product,o.value,o.status])];
      downloadText('orvex-business-pedidos-ficticios.csv', '\uFEFF'+rows.map(row => row.map(v => `"${String(v).replace(/"/g,'""')}"`).join(';')).join('\r\n'), 'text/csv;charset=utf-8');
      showToast('Arquivo CSV gerado com os dados fictícios filtrados.');
    }
    if (button.dataset.action === 'reset-dashboard') { state.orders = originalOrders.map(o => ({ ...o })); state.stock = Object.fromEntries(furniture.map((p,i) => [p.id,[12,8,6,9,14,4][i]])); state.query = ''; state.status = 'Todos'; state.selectedOrder = null; state.period = '30'; root.querySelector('[data-dashboard-period]').value = '30'; render(); showToast('Cenário demonstrativo reiniciado.'); }
  }, { signal: context.signal });
  root.addEventListener('input', event => { if (event.target.matches('[data-order-search]')) { state.query = event.target.value; content.querySelector('[data-orders-table]').innerHTML = orderTable(filteredOrders()); content.querySelector('.demo-table-count').textContent = `${filteredOrders().length} registros fictícios`; } }, { signal: context.signal });
  root.addEventListener('change', event => {
    if (event.target.matches('[data-dashboard-period]')) { state.period = event.target.value; state.selectedOrder = null; render(); }
    if (event.target.matches('[data-order-filter]')) { state.status = event.target.value; state.selectedOrder = null; render(); }
  }, { signal: context.signal });
  render();
}

function mountCorporate(root, context) {
  const state = { section: 'inicio' };
  root.innerHTML = `<div class="demo demo-corporate" data-demo="corporate"><div class="demo-corporate-header"><div class="demo-wordmark">vértice<span class="corporate-arrow">↗</span><small>ESTRATÉGIA COM DIREÇÃO</small></div><nav aria-label="Seções da página comercial">${[['inicio','Início'],['servicos','Serviços'],['sobre','Sobre'],['contato','Contato']].map(([key,label]) => `<button type="button" data-corporate-section="${key}" aria-pressed="${key === 'inicio'}">${label}</button>`).join('')}</nav></div><div class="demo-corporate-content"></div><div class="demo-bottom-note">${icon('info')}<span>Vértice é uma empresa fictícia. Este conceito não representa cliente, parceria ou serviço real da Vértice.</span></div></div>`;
  const content = root.querySelector('.demo-corporate-content');
  function render() {
    root.querySelectorAll('[data-corporate-section]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.corporateSection === state.section)));
    if (state.section === 'inicio') content.innerHTML = `<div class="demo-corporate-hero"><div><p class="demo-kicker">UMA NOVA PERSPECTIVA PARA O NEGÓCIO</p><h3 data-focus-heading tabindex="-1">Clareza para<br> ir além.</h3><p>Estratégia e organização para empresas que querem transformar a maneira como trabalham.</p><button type="button" class="demo-button" data-corporate-section="servicos">Conheça as possibilidades ${icon('up-right')}</button><span class="demo-corporate-caption">EMPRESA FICTÍCIA / CONCEITO INSTITUCIONAL</span></div><img src="/assets/images/architecture.svg" width="480" height="400" alt="Ilustração original de edifícios, representando estrutura e direção."></div><div class="demo-corporate-strip"><span>01 / Estratégia</span><span>02 / Organização</span><span>03 / Direção</span></div><div class="demo-corporate-intro"><p class="demo-kicker">UM SITE COM INTENÇÃO</p><h4>Apresentação clara.<br> Uma direção consistente.</h4><p>Este conceito demonstra como conteúdo, hierarquia e navegação podem trabalhar juntos para apresentar uma empresa.</p><button type="button" class="demo-inline-button" data-corporate-section="sobre">Conheça a proposta ${icon('arrow')}</button></div>`;
    if (state.section === 'servicos') content.innerHTML = `<div class="demo-inner-section"><p class="demo-kicker">POSSIBILIDADES / EMPRESA DEMONSTRATIVA</p><h3 data-focus-heading tabindex="-1">Organizar hoje.<br> Preparar o próximo passo.</h3><p>Conteúdos fictícios para demonstrar a apresentação de serviços em uma página institucional.</p><div class="demo-corporate-services">${[['Diagnóstico de processos','Uma leitura estruturada dos fluxos, das prioridades e dos pontos que precisam de mais clareza.'],['Organização operacional','Informações e responsabilidades apresentadas de maneira objetiva, para apoiar a rotina da empresa.'],['Planejamento de soluções','Direção para organizar necessidades e avaliar próximos passos, sem prometer resultados fora de contexto.']].map(([title,text],i) => `<details ${i === 0 ? 'open' : ''}><summary><span>0${i+1}</span>${title}${icon('plus')}</summary><p>${text}</p></details>`).join('')}</div><button type="button" class="demo-button" data-action="corporate-briefing">Quero um site com essa clareza ${icon('up-right')}</button></div>`;
    if (state.section === 'sobre') content.innerHTML = `<div class="demo-inner-section demo-corporate-about"><div><p class="demo-kicker">SOBRE ESTE CONCEITO</p><h3 data-focus-heading tabindex="-1">Uma marca de exemplo.<br> Uma experiência real.</h3><p>A Vértice foi criada exclusivamente para demonstrar uma apresentação institucional. Não há fundadores, histórico, clientes ou resultados empresariais associados a esta marca.</p><p>A navegação, os estados e a adaptação a diferentes telas mostram possibilidades de construção para uma empresa real.</p></div><div class="demo-corporate-values"><article><span>01</span><h4>Clareza</h4><p>Uma mensagem que encontra sua forma.</p></article><article><span>02</span><h4>Consistência</h4><p>Uma linguagem em todos os pontos.</p></article><article><span>03</span><h4>Intenção</h4><p>Elementos com uma função definida.</p></article></div><button type="button" class="demo-button" data-action="corporate-briefing">Conversar sobre um site institucional ${icon('up-right')}</button></div>`;
    if (state.section === 'contato') content.innerHTML = `<div class="demo-inner-section demo-corporate-contact"><p class="demo-kicker">DA DEMONSTRAÇÃO PARA A SUA IDEIA</p><h3 data-focus-heading tabindex="-1">A próxima apresentação<br> pode ser a sua.</h3><p>A Vértice não é uma empresa real e não recebe solicitações. Mas você pode usar este conceito como ponto de partida para conversar sobre a presença digital do seu negócio.</p><div class="demo-corporate-contact-note">${icon('monitor')}<div><strong>Gostou desta direção?</strong><span>O botão abaixo leva ao formulário da Orvex Systems, identificado conforme o modo de envio configurado.</span></div></div><button type="button" class="demo-button" data-action="corporate-briefing">Quero uma presença assim ${icon('up-right')}</button></div>`;
    content.querySelector('[data-focus-heading]')?.focus({ preventScroll: true });
  }
  root.addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button) return;
    if (button.dataset.corporateSection) { state.section = button.dataset.corporateSection; render(); }
    if (button.dataset.action === 'corporate-briefing') prefillBriefing('Site institucional', 'Conheci o conceito Orvex Corporate e gostaria de avaliar um site institucional com apresentação clara, navegação objetiva e identidade própria para o meu negócio.');
  }, { signal: context.signal });
  render();
}

export function mountDemo(root, kind) {
  const controller = new AbortController(), timers = new Set();
  const context = { signal: controller.signal, later(fn, delay) { const timer = setTimeout(() => { timers.delete(timer); if (!controller.signal.aborted) fn(); }, delay); timers.add(timer); return timer; } };
  root.dataset.demo = kind;
  if (kind === 'commerce' || kind === 'industrial') mountCatalog(root, kind, context);
  else if (kind === 'business') mountDashboard(root, context);
  else if (kind === 'corporate') mountCorporate(root, context);
  else root.textContent = 'Conceito não encontrado.';
  return () => { controller.abort(); timers.forEach(clearTimeout); timers.clear(); };
}
