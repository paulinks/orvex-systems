import { validateBrief, PROJECT_TYPES } from './validation.js';
import { uuid, reducedMotion } from './ui.js';

export function initForm() {
  const form = document.getElementById('briefing-form');
  const submit = document.getElementById('form-submit'), label = document.getElementById('submit-label');
  const status = document.getElementById('form-status');
  form.setAttribute('aria-busy', 'false');
  let mode = 'loading', busy = false, submitted = false, config = {}, startedAt = Date.now(), requestId = uuid();
  let turnstileToken = '', turnstileLoading = null, widgetId = null, cooldown = null;
  const fieldNames = ['name','company','contact','projectType','description','budget','timeline','consent'];
  const touched = new Set();
  const values = () => ({ ...Object.fromEntries(new FormData(form)), consent: form.elements.consent.checked });
  const updateCount = () => document.getElementById('description-count').textContent = `${form.elements.description.value.length} / 4000`;
  function message(text, type = 'info') { status.hidden = false; status.className = `form-status ${type}`; status.textContent = text; }
  function setMode(next) {
    mode = next; form.dataset.mode = next;
    const ready = next === 'ready', error = next === 'error';
    document.getElementById('form-mode-title').textContent = ready ? 'Canal de recebimento configurado' : error ? 'Não foi possível verificar o canal' : 'Formulário demonstrativo';
    document.getElementById('form-mode-description').textContent = ready ? 'O envio será confirmado somente após o processamento real.' : error ? 'Por segurança, o envio está desabilitado. Nenhum dado será transmitido.' : 'Teste os campos. Nenhuma informação será enviada ou salva.';
    document.getElementById('form-mode-pill').textContent = ready ? 'ENVIO REAL' : error ? 'OFFLINE' : 'DEMO';
    label.textContent = ready ? 'Enviar solicitação' : error ? 'Formulário indisponível' : 'Validar briefing';
    document.getElementById('form-footnote').textContent = ready ? 'Seus dados serão encaminhados ao canal comercial configurado. Não envie informações sensíveis.' : 'Demonstração: a validação acontece no navegador, sem transmissão dos dados.';
    submit.disabled = busy || error || next === 'loading';
  }
  function errorElement(name) {
    let el = document.getElementById(`${name}-error`);
    if (!el) { el = document.createElement('span'); el.id = `${name}-error`; el.className = 'field-error'; form.elements[name]?.closest('.field')?.append(el); form.elements[name]?.setAttribute('aria-describedby', el.id); }
    return el;
  }
  function renderErrors(errors, focus = false, only = null) {
    fieldNames.filter(name => !only || name === only).forEach(name => { const el = errorElement(name), field = form.elements[name]; el.textContent = errors[name] || ''; if (errors[name]) field.setAttribute('aria-invalid', 'true'); else field.removeAttribute('aria-invalid'); });
    if (focus) fieldNames.find(name => errors[name]) && form.elements[fieldNames.find(name => errors[name])]?.focus();
  }
  function setBusy(value) {
    busy = value; form.setAttribute('aria-busy', String(value)); submit.disabled = value || mode === 'error';
    document.getElementById('submit-spinner').hidden = !value; document.getElementById('submit-icon').hidden = value;
    label.textContent = value ? 'Processando solicitação…' : mode === 'ready' ? 'Enviar solicitação' : 'Validar briefing';
    form.querySelectorAll('input,select,textarea,button').forEach(el => { if (el !== submit) el.disabled = value; });
  }
  async function loadTurnstile() {
    if (!config.turnstileSiteKey) return;
    document.getElementById('turnstile-container').hidden = false;
    if (window.turnstile && widgetId !== null) return;
    if (!turnstileLoading) turnstileLoading = new Promise((resolve, reject) => {
      window.onOrvexTurnstileReady = () => {
        try { widgetId = window.turnstile.render('#turnstile-container', { sitekey: config.turnstileSiteKey, action: 'briefing', theme: 'dark', callback: token => { turnstileToken = token; message('Verificação concluída. Clique em Enviar solicitação para continuar.'); }, 'expired-callback': () => turnstileToken = '', 'error-callback': () => { turnstileToken = ''; message('A verificação de segurança falhou. Tente novamente.', 'error'); } }); resolve(); } catch (error) { reject(error); }
      };
      const script = document.createElement('script'); script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=onOrvexTurnstileReady'; script.async = true;
      script.onerror = () => reject(new Error('TURNSTILE_LOAD')); document.head.append(script);
    });
    try { await turnstileLoading; } catch { turnstileLoading = null; throw new Error('Não foi possível carregar a verificação de segurança. Verifique a conexão e tente novamente.'); }
  }
  form.addEventListener('input', event => {
    updateCount();
    if (submitted || touched.has(event.target.name)) renderErrors(validateBrief(values()).errors, false, submitted ? null : event.target.name);
    if (!busy && !status.hidden && !status.classList.contains('success')) status.hidden = true;
    if (event.target.id === 'description' && mode === 'ready' && !busy) { clearTimeout(cooldown); submit.disabled = false; }
  });
  form.addEventListener('change', event => { if (event.target.name) touched.add(event.target.name); if (submitted || touched.has(event.target.name)) renderErrors(validateBrief(values()).errors, false, submitted ? null : event.target.name); });
  form.addEventListener('blur', event => { if (fieldNames.includes(event.target.name) && event.target.value) { touched.add(event.target.name); renderErrors(validateBrief(values()).errors, false, event.target.name); } }, true);
  form.addEventListener('submit', async event => {
    event.preventDefault(); if (busy || mode === 'loading' || mode === 'error') return;
    submitted = true;
    const data = values(), result = validateBrief(data); renderErrors(result.errors, true);
    if (!result.valid) { message('Revise os campos destacados para continuar.', 'error'); return; }
    if (form.elements.website.value) { message('Não foi possível validar a solicitação. Atualize a página e tente novamente.', 'error'); return; }
    if (mode === 'demo') { message('Briefing validado. Este formulário é demonstrativo: nenhum dado foi enviado ou salvo.'); return; }
    if (Date.now() - startedAt < 2500) { message('Aguarde alguns segundos antes de enviar o formulário.', 'error'); return; }
    if (config.turnstileSiteKey && !turnstileToken) {
      setBusy(true);
      try { await loadTurnstile(); message('Conclua a verificação de segurança abaixo e clique em Enviar solicitação.'); }
      catch (error) { message(error.message, 'error'); }
      finally { setBusy(false); }
      return;
    }
    setBusy(true); status.hidden = true;
    const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 35000);
    try {
      const response = await fetch('/api/inquiries', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...result.values, website: data.website, startedAt, requestId, turnstileToken }), signal: controller.signal });
      const body = await response.json();
      if (response.ok && body.ok === true) {
        message(body.message, 'success'); form.reset(); touched.clear(); renderErrors({}); updateCount(); submitted = false;
        startedAt = Date.now(); requestId = uuid(); turnstileToken = '';
        if (window.turnstile && widgetId !== null) window.turnstile.reset(widgetId);
        label.textContent = 'Solicitação recebida'; submit.disabled = true;
        cooldown = setTimeout(() => { submit.disabled = false; label.textContent = 'Enviar outra solicitação'; }, 12000);
        status.tabIndex = -1; status.focus({ preventScroll: true });
      } else if (body.code === 'VALIDATION') { renderErrors(body.errors, true); message('Revise os campos destacados.', 'error'); }
      else if (body.code === 'DEMO') { setMode('demo'); message(body.error); }
      else if (body.code === 'DUPLICATE') { message(body.error); submit.disabled = true; }
      else { message(body.error || 'Não foi possível confirmar o envio. Tente novamente mais tarde.', 'error'); }
      if (!response.ok && window.turnstile && widgetId !== null) { window.turnstile.reset(widgetId); turnstileToken = ''; }
    } catch (error) {
      message(error.name === 'AbortError' ? 'O serviço demorou a responder. Não foi possível confirmar o recebimento. Tente novamente mais tarde.' : 'A conexão foi interrompida. Nenhum recebimento foi confirmado. Seus campos foram preservados para uma nova tentativa.', 'error');
      if (window.turnstile && widgetId !== null) { window.turnstile.reset(widgetId); turnstileToken = ''; }
    } finally { clearTimeout(timeout); setBusy(false); if (status.classList.contains('success')) { submit.disabled = true; label.textContent = 'Solicitação recebida'; } }
  });
  window.addEventListener('orvex:prefill', event => {
    const { type, description } = event.detail;
    if (PROJECT_TYPES.includes(type)) form.elements.projectType.value = type;
    if (description) {
      const field = form.elements.description;
      if (!field.value.includes(description)) field.value = [field.value.trim(), description].filter(Boolean).join('\n\n').slice(0, 4000);
      updateCount(); if (submitted) renderErrors(validateBrief(values()).errors);
      message('Resumo do conceito adicionado ao briefing. Revise o texto antes de continuar. Nada foi enviado.');
    }
  });
  updateCount();
  return {
    configure(next) { config = next; setMode(next.formEnabled ? 'ready' : 'demo'); startedAt = Date.now(); },
    connectionError() { setMode('error'); message('Não foi possível verificar o serviço de recebimento. Tente recarregar a página. Nenhum dado será enviado.'); const retry = document.createElement('button'); retry.type = 'button'; retry.className = 'inline-link retry-config'; retry.textContent = 'Verificar novamente'; retry.addEventListener('click', () => location.reload()); status.append(document.createElement('br'), retry); },
    setType(type) { if (PROJECT_TYPES.includes(type)) { form.elements.projectType.value = type; if (submitted) renderErrors(validateBrief(values()).errors); } }
  };
}
