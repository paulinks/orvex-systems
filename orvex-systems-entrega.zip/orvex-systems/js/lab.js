import { mountDemo } from './demos.js';
const labels = { commerce: ['catálogo', 'tab-catalog'], business: ['dashboard', 'tab-dashboard'], corporate: ['página-comercial', 'tab-commercial'] };
export function initLab() {
  const tabs = [...document.querySelectorAll('[data-lab]')];
  const panel = document.getElementById('lab-panel');
  let cleanup = () => {}, active = 'commerce';
  const activate = (tab, focus = false) => {
    cleanup(); active = tab.dataset.lab;
    tabs.forEach(button => { const selected = button === tab; button.classList.toggle('active', selected); button.setAttribute('aria-selected', String(selected)); button.tabIndex = selected ? 0 : -1; });
    panel.setAttribute('aria-labelledby', tab.id);
    document.getElementById('lab-address').textContent = `orvex / lab / ${labels[active][0]}`;
    cleanup = mountDemo(panel, active);
    if (focus) tab.focus();
  };
  tabs.forEach(tab => tab.addEventListener('click', () => { if (active !== tab.dataset.lab) activate(tab); }));
  document.querySelector('.lab-tabs').addEventListener('keydown', event => {
    const index = tabs.findIndex(tab => tab.dataset.lab === active);
    let next;
    if (['ArrowRight','ArrowDown'].includes(event.key)) next = (index + 1) % tabs.length;
    if (['ArrowLeft','ArrowUp'].includes(event.key)) next = (index + tabs.length - 1) % tabs.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = tabs.length - 1;
    if (next !== undefined) { event.preventDefault(); activate(tabs[next], true); }
  });
  activate(tabs[0]);
}
