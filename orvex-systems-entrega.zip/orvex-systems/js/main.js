import { initUI, applySiteConfig, openDialog } from './ui.js';
import { initProjects } from './projects.js';
import { initLab } from './lab.js';
import { initForm } from './form.js';

initUI();
initProjects();
initLab();
const form = initForm();
document.querySelectorAll('[data-project-type]').forEach(link => link.addEventListener('click', () => form.setType(link.dataset.projectType)));
document.querySelectorAll('[data-privacy]').forEach(button => button.addEventListener('click', event => { event.preventDefault(); openDialog(document.getElementById('privacy-dialog')); }));
document.querySelectorAll('[data-whatsapp]').forEach(button => button.addEventListener('click', () => openDialog(document.getElementById('contact-dialog'))));
document.getElementById('contact-to-form').addEventListener('click', () => {
  document.getElementById('contact-dialog').close();
  requestAnimationFrame(() => { document.getElementById('contato').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' }); document.getElementById('name').focus({ preventScroll: true }); });
});
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 7000);
try {
  const response = await fetch('/api/config', { signal: controller.signal, headers: { Accept: 'application/json' } });
  if (!response.ok && response.status !== 404) throw new Error('Configuração indisponível');
  const config = response.status === 404 ? { formEnabled: false } : await response.json();
  if (typeof config.formEnabled !== 'boolean') throw new Error('Configuração inválida');
  applySiteConfig(config); form.configure(config);
} catch {
  form.connectionError();
} finally { clearTimeout(timeout); }
