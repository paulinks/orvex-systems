document.getElementById('legal-year').textContent = new Date().getFullYear();
const mode = document.getElementById('privacy-mode');
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 7000);
try {
  const response = await fetch('/api/config', { signal: controller.signal });
  if (!response.ok && response.status !== 404) throw new Error('Configuração indisponível');
  const config = response.status === 404 ? { formEnabled: false } : await response.json();
  mode.textContent = config.formEnabled ? 'O envio real está configurado neste ambiente. Os dados enviados serão tratados pelas finalidades e condições descritas abaixo, sob responsabilidade do controlador identificado.' : 'Este ambiente está em modo de demonstração. O formulário valida os campos localmente: nenhum briefing é transmitido ou armazenado pelo site.';
  if (config.formEnabled && config.privacyController) document.querySelectorAll('[data-privacy-controller]').forEach(el => el.textContent = config.privacyController);
  if (config.formEnabled && config.privacyEmail) document.querySelectorAll('[data-privacy-email]').forEach(el => { const link = document.createElement('a'); link.href = `mailto:${config.privacyEmail}`; link.textContent = config.privacyEmail; el.replaceChildren(link); });
} catch { mode.textContent = 'Não foi possível verificar o serviço de recebimento. Por segurança, o formulário permanece desabilitado até que a configuração seja verificada.'; }
finally { clearTimeout(timeout); }
