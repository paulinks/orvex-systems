import { openDialog, syncScrollLock } from './ui.js';
import { mountDemo } from './demos.js';

const projects = {
  commerce: { name: 'Orvex Commerce', category: '01 / COMÉRCIO DIGITAL' },
  business: { name: 'Orvex Business', category: '02 / GESTÃO & OPERAÇÃO' },
  corporate: { name: 'Orvex Corporate', category: '03 / PRESENÇA INSTITUCIONAL' },
  industrial: { name: 'Orvex Industrial', category: '04 / CATÁLOGO B2B' }
};
export function initProjects() {
  const region = document.querySelector('.project-carousel');
  const track = region.querySelector('.project-track');
  const slides = [...region.querySelectorAll('.project-slide')];
  const dots = [...region.querySelectorAll('[data-slide]')];
  let current = 0, startX = null, startY = null;
  const go = (index, announce = true) => {
    current = (index + slides.length) % slides.length;
    track.style.transform = `translateX(-${current * 100}%)`;
    slides.forEach((slide, i) => { slide.setAttribute('aria-hidden', String(i !== current)); slide.inert = i !== current; });
    dots.forEach((dot, i) => { if (i === current) dot.setAttribute('aria-current', 'true'); else dot.removeAttribute('aria-current'); });
    document.getElementById('project-current').textContent = String(current + 1).padStart(2, '0');
    if (announce) document.getElementById('carousel-announcement').textContent = `Projeto ${current + 1} de 4: ${projects[slides[current].dataset.project].name}.`;
  };
  document.querySelector('.carousel-prev').addEventListener('click', () => go(current - 1));
  document.querySelector('.carousel-next').addEventListener('click', () => go(current + 1));
  dots.forEach(dot => dot.addEventListener('click', () => go(Number(dot.dataset.slide))));
  region.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft') { event.preventDefault(); go(current - 1); }
    if (event.key === 'ArrowRight') { event.preventDefault(); go(current + 1); }
    if (event.key === 'Home') { event.preventDefault(); go(0); }
    if (event.key === 'End') { event.preventDefault(); go(3); }
  });
  track.addEventListener('pointerdown', event => {
    if (event.target.closest('button,a,input,select') || event.pointerType === 'mouse') return;
    startX = event.clientX; startY = event.clientY;
  });
  track.addEventListener('pointerup', event => {
    if (startX === null) return;
    const dx = event.clientX - startX, dy = event.clientY - startY;
    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.3) go(current + (dx < 0 ? 1 : -1));
    startX = startY = null;
  });
  track.addEventListener('pointercancel', () => startX = startY = null);
  const dialog = document.getElementById('experience-dialog');
  const content = document.getElementById('experience-content');
  let cleanup = () => {};
  const open = (kind) => {
    if (!projects[kind]) return;
    cleanup();
    document.getElementById('experience-title').textContent = projects[kind].name;
    document.getElementById('experience-category').textContent = projects[kind].category;
    cleanup = mountDemo(content, kind);
    openDialog(dialog); dialog.scrollTop = 0;
  };
  document.querySelectorAll('[data-open-project]').forEach(button => button.addEventListener('click', () => open(button.dataset.openProject)));
  dialog.addEventListener('close', () => { cleanup(); cleanup = () => {}; syncScrollLock(); });
  go(0, false);
}
