export const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
export const escapeHTML = (value) => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const icon = (name, extra = '') => `<svg class="icon ${extra}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
export const uuid = () => {
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
  const hex = [...bytes].map(b => b.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
};
export function syncScrollLock() { document.body.classList.toggle('modal-open', Boolean(document.querySelector('dialog[open]'))); }
export function openDialog(dialog) {
  document.querySelectorAll('dialog[open]').forEach(other => { if (other !== dialog) other.close(); });
  if (!dialog.open) dialog.showModal();
  syncScrollLock();
}
export function closeDialogs() { document.querySelectorAll('dialog[open]').forEach(dialog => dialog.close()); syncScrollLock(); }
let toastTimer;
export function showToast(message) {
  let toast = document.getElementById('demo-toast');
  if (!toast) { toast = document.createElement('div'); toast.id = 'demo-toast'; toast.className = 'demo-toast'; toast.setAttribute('role', 'status'); toast.setAttribute('aria-live', 'polite'); }
  const host = document.querySelector('dialog[open]') || document.body;
  host.append(toast); toast.textContent = message; toast.classList.add('visible');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('visible'), 4200);
}
export function goToSection(id) {
  closeDialogs();
  requestAnimationFrame(() => {
    const target = document.getElementById(id);
    target?.scrollIntoView({ behavior: reducedMotion() ? 'instant' : 'smooth', block: 'start' });
    if (id === 'contato') document.getElementById('name')?.focus({ preventScroll: true });
  });
}
export function prefillBriefing(type, description) {
  window.dispatchEvent(new CustomEvent('orvex:prefill', { detail: { type, description } }));
  goToSection('contato');
}
export async function copyText(text, area) {
  try { if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(text); return true; } } catch {}
  if (area) { area.focus(); area.select(); try { return document.execCommand('copy'); } catch {} }
  return false;
}
export function downloadText(filename, text, mime = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = document.createElement('a'); a.href = url; a.download = filename;
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1500);
}
export function initUI() {
  document.documentElement.classList.add('js');
  const reveal = document.querySelectorAll('.reveal');
  if (reducedMotion() || !('IntersectionObserver' in window)) reveal.forEach(el => el.classList.add('is-visible'));
  else {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); } }), { threshold: .06, rootMargin: '0px 0px -22px 0px' });
    reveal.forEach(el => observer.observe(el));
  }
  const header = document.getElementById('site-header');
  let scheduled = false;
  const updateHeader = () => { header.classList.toggle('scrolled', window.scrollY > 24); scheduled = false; };
  window.addEventListener('scroll', () => { if (!scheduled) { requestAnimationFrame(updateHeader); scheduled = true; } }, { passive: true });
  updateHeader();
  if ('IntersectionObserver' in window) {
    const nav = document.querySelector('.desktop-nav');
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) nav.querySelectorAll('a').forEach(a => { if (a.hash === `#${entry.target.id}`) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current'); });
    }), { rootMargin: '-15% 0px -65% 0px', threshold: 0 });
    ['inicio','solucoes','portfolio','processo','sobre','contato'].forEach(id => observer.observe(document.getElementById(id)));
  }
  document.querySelectorAll('dialog').forEach(dialog => {
    dialog.addEventListener('close', syncScrollLock);
    dialog.addEventListener('keydown', event => {
      if (event.key !== 'Tab') return;
      const focusable = [...dialog.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),summary,[tabindex]:not([tabindex="-1"])')].filter(el => el.getClientRects().length && !el.closest('[inert]') && getComputedStyle(el).visibility !== 'hidden');
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (!first) { event.preventDefault(); return; }
      if (event.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !dialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    });
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const r = dialog.getBoundingClientRect();
      if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close();
    });
  });
  document.addEventListener('click', event => {
    const close = event.target.closest('[data-close]');
    if (close) { close.closest('dialog')?.close(); return; }
    const anchor = event.target.closest('a[href^="#"]');
    if (anchor && document.getElementById(anchor.hash.slice(1))) closeDialogs();
  });
  const menu = document.getElementById('mobile-menu'), toggle = document.getElementById('menu-toggle');
  toggle.addEventListener('click', () => { openDialog(menu); toggle.setAttribute('aria-expanded', 'true'); });
  menu.addEventListener('close', () => toggle.setAttribute('aria-expanded', 'false'));
  window.matchMedia('(min-width: 1001px)').addEventListener('change', event => { if (event.matches && menu.open) menu.close(); });
  const labTabs = document.querySelector('.lab-tabs');
  const updateOrientation = () => labTabs.setAttribute('aria-orientation', window.innerWidth <= 760 ? 'horizontal' : 'vertical');
  window.addEventListener('resize', updateOrientation, { passive: true }); updateOrientation();
  document.querySelectorAll('.faq-list details').forEach(details => details.addEventListener('toggle', () => {
    if (details.open) document.querySelectorAll('.faq-list details').forEach(other => { if (other !== details) other.open = false; });
  }));
  document.getElementById('current-year').textContent = new Date().getFullYear();
}
export function applySiteConfig(config) {
  if (config.whatsapp) {
    document.querySelectorAll('[data-whatsapp]').forEach(button => {
      const link = document.createElement('a'); link.href = `https://wa.me/${config.whatsapp}?text=${encodeURIComponent('Olá! Conheci o portfólio da Orvex Systems e gostaria de conversar sobre um projeto digital.')}`;
      link.target = '_blank'; link.rel = 'noopener noreferrer'; link.className = button.className;
      link.innerHTML = button.innerHTML; link.setAttribute('aria-label', 'Conversar com a Orvex Systems no WhatsApp');
      button.replaceWith(link);
    });
    document.getElementById('whatsapp-note').textContent = 'Abrir uma conversa no canal oficial.';
    document.getElementById('footer-contact-note').textContent = 'Converse pelo canal oficial da Orvex Systems.';
  }
  if (config.contactEmail) {
    for (const id of ['contact-email','footer-email']) { const a = document.getElementById(id); a.href = `mailto:${config.contactEmail}`; a.textContent = id === 'contact-email' ? config.contactEmail : 'E-mail comercial'; a.hidden = false; }
    if (!config.whatsapp) document.getElementById('footer-contact-note').textContent = 'Contato pelo e-mail oficial informado.';
  }
  const socials = document.getElementById('footer-socials');
  for (const [key,label] of [['instagram','Instagram'],['linkedin','LinkedIn']]) if (config[key]) { const a = document.createElement('a'); a.href = config[key]; a.textContent = label; a.target = '_blank'; a.rel = 'noopener noreferrer'; socials.append(a); }
  if (config.privacyController) document.querySelectorAll('[data-privacy-controller]').forEach(el => el.textContent = config.privacyController);
  if (config.privacyEmail) document.querySelectorAll('[data-privacy-email]').forEach(el => { const a = document.createElement('a'); a.href = `mailto:${config.privacyEmail}`; a.textContent = config.privacyEmail; el.replaceChildren(a); });
}
