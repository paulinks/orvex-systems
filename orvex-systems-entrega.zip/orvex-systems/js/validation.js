export const PROJECT_TYPES = ['Site institucional', 'Landing page', 'Catálogo digital', 'Loja virtual', 'Sistema personalizado', 'Automação ou integração', 'Outro'];
export const BUDGETS = ['Até R$ 3.000', 'R$ 3.000 a R$ 7.000', 'R$ 7.000 a R$ 15.000', 'Acima de R$ 15.000', 'Prefiro conversar'];
export const TIMELINES = ['Até 30 dias', 'De 1 a 2 meses', 'De 2 a 4 meses', 'Mais de 4 meses', 'Flexível'];
export const isEmail = (value) => typeof value === 'string' && value.length <= 160 && /^[^\s@<>(),;:\[\]\\"]+@[^\s@<>(),;:\[\]\\".]+(?:\.[^\s@<>(),;:\[\]\\".]+)+$/.test(value);
export const phoneDigits = (value) => String(value).replace(/\D/g, '');
export const isPhone = (value) => typeof value === 'string' && /^[+\d\s().-]+$/.test(value) && phoneDigits(value).length >= 10 && phoneDigits(value).length <= 15;
export function validateBrief(input = {}) {
  const source = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  const text = (key, max) => typeof source[key] === 'string' ? source[key].trim().slice(0, max + 1) : '';
  const values = {
    name: text('name', 100), company: text('company', 120), contact: text('contact', 160),
    projectType: text('projectType', 80), description: text('description', 4000),
    budget: text('budget', 80), timeline: text('timeline', 80), consent: source.consent === true
  };
  const errors = {};
  if (values.name.length < 2) errors.name = 'Informe seu nome com pelo menos 2 caracteres.';
  else if (values.name.length > 100 || /[\r\n<>]/.test(values.name)) errors.name = 'Use um nome de até 100 caracteres, sem quebras de linha ou marcações.';
  if (values.company.length > 120 || /[\r\n<>]/.test(values.company)) errors.company = 'Use até 120 caracteres, sem quebras de linha ou marcações.';
  if (!values.contact) errors.contact = 'Informe um e-mail ou WhatsApp para contato.';
  else if (!isEmail(values.contact) && !isPhone(values.contact)) errors.contact = 'Informe um e-mail válido ou um telefone com DDD, por exemplo: (11) 99999-9999.';
  if (!PROJECT_TYPES.includes(values.projectType)) errors.projectType = 'Selecione um dos tipos de projeto da lista.';
  if (values.description.length < 20) errors.description = 'Conte um pouco mais: use pelo menos 20 caracteres.';
  else if (values.description.length > 4000) errors.description = 'A descrição deve ter no máximo 4.000 caracteres.';
  else if (/(?:https?:\/\/\S+\s*){4,}/i.test(values.description)) errors.description = 'Remova o excesso de links e descreva a necessidade do projeto.';
  if (values.budget && !BUDGETS.includes(values.budget)) errors.budget = 'Selecione uma faixa de investimento válida.';
  if (values.timeline && !TIMELINES.includes(values.timeline)) errors.timeline = 'Selecione um prazo válido.';
  if (!values.consent) errors.consent = 'Leia a política e confirme a autorização para tratar desta solicitação.';
  return { values, errors, valid: Object.keys(errors).length === 0 };
}
