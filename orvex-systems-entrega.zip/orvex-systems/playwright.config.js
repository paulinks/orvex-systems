import { defineConfig, devices } from '@playwright/test';
const empty={SMTP_HOST:'',SMTP_USER:'',SMTP_PASS:'',MAIL_FROM:'',MAIL_TO:'',PRIVACY_CONTROLLER:'',PRIVACY_EMAIL:'',WHATSAPP_NUMBER:'',CONTACT_EMAIL:'',PUBLIC_SITE_URL:'',TURNSTILE_SITE_KEY:'',TURNSTILE_SECRET_KEY:'',INSTAGRAM_URL:'',LINKEDIN_URL:'',ORVEX_STATIC_DIR:''};
export default defineConfig({
  testDir:'./tests',testMatch:'**/*.spec.js',fullyParallel:true,forbidOnly:true,retries:0,workers:2,timeout:30000,
  reporter:[['list'],['json',{outputFile:'tests/results.json'}]],
  use:{baseURL:'http://127.0.0.1:3100',reducedMotion:'reduce',trace:'retain-on-failure',screenshot:'only-on-failure'},
  projects:[{name:'desktop',use:{...devices['Desktop Chrome'],viewport:{width:1440,height:1000}}},{name:'mobile',use:{...devices['Pixel 7'],viewport:{width:393,height:851}}}],
  webServer:{command:'node server.mjs',url:'http://127.0.0.1:3100',reuseExistingServer:false,env:{...empty,PORT:'3100',HOST:'127.0.0.1'},timeout:15000}
});
