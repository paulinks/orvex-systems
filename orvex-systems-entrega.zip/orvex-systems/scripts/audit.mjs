import { chromium } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { once } from 'node:events';
import { writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createAppServer } from '../server.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const server=createAppServer({root:path.join(root,'build'),env:{SMTP_HOST:'',SMTP_USER:'',SMTP_PASS:'',MAIL_FROM:'',MAIL_TO:'',PRIVACY_CONTROLLER:'',PRIVACY_EMAIL:'',WHATSAPP_NUMBER:'',CONTACT_EMAIL:'',PUBLIC_SITE_URL:'',TURNSTILE_SITE_KEY:'',TURNSTILE_SECRET_KEY:'',INSTAGRAM_URL:'',LINKEDIN_URL:''}});
server.listen(0,'127.0.0.1');await once(server,'listening');const base=`http://127.0.0.1:${server.address().port}`;
const browser=await chromium.launch();await mkdir(path.join(root,'tests/screenshots'),{recursive:true});
const report={timestamp:new Date().toISOString(),environment:'Build local de produção, Chromium headless, rede local. Não representa métricas de campo nem auditoria Lighthouse.',contexts:[]};
try {
  for (const device of [{name:'desktop',viewport:{width:1440,height:1000},mobile:false},{name:'mobile',viewport:{width:390,height:844},mobile:true}]) {
    const context=await browser.newContext({viewport:device.viewport,isMobile:device.mobile,hasTouch:device.mobile,deviceScaleFactor:1});const page=await context.newPage();
    const errors=[];page.on('pageerror',error=>errors.push(error.message));
    await page.addInitScript(()=>{
      window.__orvexMetrics={lcp:0,cls:0,lcpElement:''};let session=0,last=0,start=0;
      new PerformanceObserver(list=>{for(const entry of list.getEntries()){window.__orvexMetrics.lcp=entry.startTime;window.__orvexMetrics.lcpElement=entry.element?.tagName+'.'+(entry.element?.className||'');}}).observe({type:'largest-contentful-paint',buffered:true});
      new PerformanceObserver(list=>{for(const entry of list.getEntries()){if(entry.hadRecentInput)continue;if(session&&entry.startTime-last<1000&&entry.startTime-start<5000)session+=entry.value;else{session=entry.value;start=entry.startTime;}last=entry.startTime;window.__orvexMetrics.cls=Math.max(window.__orvexMetrics.cls,session);}}).observe({type:'layout-shift',buffered:true});
    });
    let cdp;
    if(device.mobile){cdp=await context.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});await cdp.send('Network.enable');await cdp.send('Network.emulateNetworkConditions',{offline:false,latency:100,downloadThroughput:1600000/8,uploadThroughput:750000/8,connectionType:'cellular4g'});}
    await page.goto(base,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(1400);
    const metrics=await page.evaluate(()=>{const nav=performance.getEntriesByType('navigation')[0],resources=performance.getEntriesByType('resource');return {...window.__orvexMetrics,fcp:performance.getEntriesByName('first-contentful-paint')[0]?.startTime,domContentLoadedMs:nav?.domContentLoadedEventEnd,loadMs:nav?.loadEventEnd,initialTransferKiB:((nav?.transferSize||0)+resources.reduce((sum,r)=>sum+(r.transferSize||0),0))/1024,resources:resources.length};});
    if(cdp){await cdp.send('Emulation.setCPUThrottlingRate',{rate:1});await cdp.send('Network.emulateNetworkConditions',{offline:false,latency:0,downloadThroughput:-1,uploadThroughput:-1});}
    await page.emulateMedia({reducedMotion:'reduce'});
    const runAxe=async selector=>{let builder=new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']);if(selector)builder=builder.include(selector);const result=await builder.analyze();return {violations:result.violations.map(v=>({id:v.id,impact:v.impact,targets:v.nodes.map(n=>n.target)})),passes:result.passes.length,incomplete:result.incomplete.map(v=>({id:v.id,targets:v.nodes.map(n=>n.target)}))};};
    for(const id of ['solucoes','portfolio','laboratorio','processo','sobre','faq','contato']){await page.locator('#'+id).evaluate(el=>el.scrollIntoView({block:'start',behavior:'instant'}));await page.waitForTimeout(100);}
    const homeAxe=await runAxe();
    await page.evaluate(()=>scrollTo({top:0,behavior:'instant'}));await page.waitForTimeout(250);await page.screenshot({path:path.join(root,`tests/screenshots/${device.name}-hero-final.png`)});
    if(!device.mobile){for(const id of ['solucoes','portfolio','laboratorio','contato']){await page.locator('#'+id).evaluate(el=>el.scrollIntoView({block:'start',behavior:'instant'}));await page.waitForTimeout(150);await page.screenshot({path:path.join(root,`tests/screenshots/desktop-${id}-final.png`)});}}
    else {await page.evaluate(()=>scrollTo({top:570,behavior:'instant'}));await page.screenshot({path:'tests/screenshots/mobile-art-final.png'});await page.locator('#laboratorio').evaluate(el=>el.scrollIntoView({block:'start',behavior:'instant'}));await page.screenshot({path:'tests/screenshots/mobile-lab-final.png'});await page.locator('#contato').evaluate(el=>el.scrollIntoView({block:'start',behavior:'instant'}));await page.screenshot({path:'tests/screenshots/mobile-form-final.png'});}
    const stateAudits={home:homeAxe};
    for(const [tab,label] of [['tab-catalog','catalog'],['tab-dashboard','dashboard'],['tab-commercial','corporate']]){await page.locator('#'+tab).click();stateAudits[label]=await runAxe('#laboratorio');if(label==='dashboard')await page.screenshot({path:path.join(root,`tests/screenshots/${device.name}-dashboard-final.png`)});}
    for(const [index,label] of [[0,'commerce-modal'],[1,'business-modal'],[2,'corporate-modal'],[3,'industrial-modal']]){await page.locator(`[data-slide="${index}"]`).click();await page.locator('.project-slide[aria-hidden="false"] [data-open-project]').click();stateAudits[label]=await runAxe('#experience-dialog');if(index===3)await page.screenshot({path:path.join(root,`tests/screenshots/${device.name}-industrial-final.png`)});await page.keyboard.press('Escape');}
    await page.locator('.consent-field [data-privacy]').click();stateAudits.privacy=await runAxe('#privacy-dialog');await page.keyboard.press('Escape');
    const overflow=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth}));
    const brokenImages=await page.locator('img').evaluateAll(images=>images.filter(img=>img.complete&&img.naturalWidth===0).map(img=>img.src));
    report.contexts.push({device:device.name,viewport:device.viewport,throttling:device.mobile?'CPU 4×; rede simulada 1,6 Mbps down / 750 kbps up; latência 100 ms':'Sem throttling artificial',metrics,axe:stateAudits,consoleErrors:errors,overflow,brokenImages});
    await context.close();
  }
  const compression=await fetch(base+'/css/styles.css',{headers:{'Accept-Encoding':'br'}});report.compression={status:compression.status,encoding:compression.headers.get('content-encoding'),vary:compression.headers.get('vary')};await compression.arrayBuffer();
  await writeFile(path.join(root,'tests/audit.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report,null,2));
} finally {await browser.close();server.close();server.closeAllConnections();}
