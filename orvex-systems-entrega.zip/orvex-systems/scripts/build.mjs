import { build } from 'esbuild';
import { cp, mkdir, readFile, writeFile, rm, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { gzipSync, brotliCompressSync, constants } from 'node:zlib';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createConfig } from '../server.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'build');
const config = createConfig();
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
await cp(path.join(root, 'assets'), path.join(out, 'assets'), { recursive: true });
await build({ absWorkingDir: root, entryPoints: ['js/main.js','js/privacy.js'], outdir: path.join(out,'js'), bundle: true, splitting: true, format: 'esm', target: 'es2022', minify: true, sourcemap: false, legalComments: 'none', logLevel: 'info' });
await build({ absWorkingDir: root, entryPoints: ['css/styles.css','css/pages.css'], outdir: path.join(out,'css'), bundle: true, minify: true, external: ['/assets/*'], logLevel: 'info' });
const escapeAttr = value => String(value).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;');
for (const filename of ['index.html','privacidade.html','404.html']) {
  let html = await readFile(path.join(root,filename),'utf8');
  if (config.siteURL) {
    const url = config.siteURL + (filename === 'index.html' ? '/' : `/${filename}`);
    const image = `${config.siteURL}/assets/images/og-orvex.png`;
    html = html.replace('content="/assets/images/og-orvex.png"', `content="${escapeAttr(image)}"`);
    const tags = [`<link rel="canonical" href="${escapeAttr(url)}">`,`<meta property="og:url" content="${escapeAttr(url)}">`];
    if (filename === 'index.html') {
      const organization = { '@context':'https://schema.org', '@type':'Organization', name:'Orvex Systems', url:config.siteURL, logo:`${config.siteURL}/assets/images/orvex-mark.svg`, description:'Estúdio de soluções digitais: sites, plataformas, sistemas personalizados e integrações.' };
      const sameAs = [config.instagram,config.linkedin].filter(Boolean); if (sameAs.length) organization.sameAs = sameAs;
      tags.push(`<script type="application/ld+json">${JSON.stringify(organization).replaceAll('<','\\u003c')}</script>`);
    }
    html = html.replace('</head>', tags.join('\n')+'\n</head>');
  }
  await writeFile(path.join(out,filename),html);
}
await writeFile(path.join(out,'robots.txt'), config.siteURL ? `User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: ${config.siteURL}/sitemap.xml\n` : 'User-agent: *\nDisallow: /\n');
if (config.siteURL) await writeFile(path.join(out,'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${config.siteURL}/</loc></url><url><loc>${config.siteURL}/privacidade.html</loc></url></urlset>\n`);
for (const filename of ['index.html','privacidade.html','404.html']) {
  const html = await readFile(path.join(out,filename),'utf8');
  for (const match of html.matchAll(/(?:src|href)="(\/[^"#?]+)(?:[?#][^"]*)?"/g)) {
    if (!existsSync(path.join(out,match[1]))) throw new Error(`Recurso local não encontrado: ${match[1]} em ${filename}`);
  }
}
if (!existsSync(path.join(out,'assets/images/og-orvex.png'))) throw new Error('Imagem de compartilhamento não encontrada. Execute o roteiro de preparação de assets.');
const size = async dir => { let total=0; for (const entry of await import('node:fs/promises').then(m=>m.readdir(dir,{withFileTypes:true}))) total += entry.isDirectory() ? await size(path.join(dir,entry.name)) : (await stat(path.join(dir,entry.name))).size; return total; };
const compress = async dir => {
  const { readdir } = await import('node:fs/promises');
  for (const entry of await readdir(dir,{withFileTypes:true})) {
    const file = path.join(dir,entry.name);
    if (entry.isDirectory()) { await compress(file); continue; }
    if (!/\.(html|css|js|svg|xml|txt|json)$/.test(entry.name)) continue;
    const content = await readFile(file);
    await writeFile(file+'.gz',gzipSync(content,{level:9}));
    await writeFile(file+'.br',brotliCompressSync(content,{params:{[constants.BROTLI_PARAM_QUALITY]:11}}));
  }
};
await compress(out);
console.log(`Build pronto: ${(await size(out)/1024).toFixed(1)} KiB em build/, incluindo variantes gzip e Brotli.`);
if (!config.siteURL) console.warn('PUBLIC_SITE_URL não configurado: sem canonical/sitemap públicos; servidor mantém noindex. Configure o domínio antes de publicar.');
if (!config.formEnabled) console.warn('Formulário em DEMONSTRAÇÃO. Configure SMTP e identificação de privacidade para habilitar o envio real.');
