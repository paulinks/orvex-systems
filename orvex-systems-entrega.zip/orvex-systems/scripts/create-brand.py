"""Assinaturas vetoriais originais, com tipografia convertida em caminhos."""
from pathlib import Path
from math import ceil
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets'/'brand';OUT.mkdir(parents=True,exist_ok=True)
font_path=ROOT/'assets/fonts/space-grotesk-latin.woff2'
fonts={w:instantiateVariableFont(TTFont(font_path),{'wght':w},inplace=True) for w in (400,600)}
def word(text,weight,x,y,size,color,spacing=20):
    font=fonts[weight];glyphs=font.getGlyphSet();cmap=font.getBestCmap();scale=size/font['head'].unitsPerEm
    parts=[];cursor=0
    for char in text:
        name=cmap.get(ord(char));
        if not name: continue
        pen=SVGPathPen(glyphs);glyphs[name].draw(pen)
        parts.append(f'<path transform="translate({cursor:.2f} 0)" d="{pen.getCommands()}"/>')
        cursor+=glyphs[name].width+spacing
    return f'<g fill="{color}" transform="translate({x:.2f} {y:.2f}) scale({scale:.6f} {-scale:.6f})">'+''.join(parts)+'</g>',(cursor-spacing)*scale
MARK='<path d="M1 3h11l12 17-6 8L1 3Z"/><path d="M28 3h11L27 20l-6-8 7-9Z"/><path d="m12 25 6 8-6 7H1l11-15Z"/><path d="m28 24 11 16H28l-6-8 6-8Z"/>'
def mark(x,y,scale,color,mono=False):
    svg=f'<g transform="translate({x} {y}) scale({scale})" fill="{color}">{MARK}</g>'
    if not mono: svg=svg.replace('<path d="M28 3h11L27 20l-6-8 7-9Z"/>','<path d="M28 3h11L27 20l-6-8 7-9Z" fill="#E32636"/>')
    return svg
def save(name,width,height,body):
    (OUT/name).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-labelledby="title"><title id="title">Orvex Systems</title><desc>Assinatura tipográfica com X geométrico construído em quatro módulos.</desc>{body}</svg>')
for name,color,mono in [('orvex-systems-horizontal.svg','#F3F5F8',False),('orvex-systems-monocromatica-branca.svg','#FFFFFF',True),('orvex-systems-monocromatica-preta.svg','#090B10',True)]:
    first,w1=word('Orvex ',600,62,43,30,color)
    second,w2=word('Systems',400,62+w1,43,30,color)
    save(name,ceil(62+w1+w2+8),64,mark(0,9,1.1,color,mono)+first+second)
first,w1=word('Orvex',600,57,29,26,'#F3F5F8')
second,w2=word('Systems',400,57,55,23,'#F3F5F8')
save('orvex-systems-compacta.svg',ceil(57+max(w1,w2)+7),68,mark(0,10,1.1,'#F3F5F8')+first+second)
print('Quatro assinaturas SVG com texto vetorial geradas.')
