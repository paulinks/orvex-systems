import http from 'node:http';
import { createReadStream, existsSync } from 'node:fs';
import { stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';
import { validateBrief, isEmail, phoneDigits } from './js/validation.js';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
if (existsSync(path.join(ROOT, '.env')) && process.loadEnvFile) process.loadEnvFile(path.join(ROOT, '.env'));
const clean = (v) => String(v || '').trim();
const validWebURL = (value, hosts) => {
  try { const u = new URL(value); return u.protocol === 'https:' && !u.username && !u.password && hosts.includes(u.hostname) ? u.href : null; } catch { return null; }
};
export function createConfig(env = process.env) {
  const whatsapp = clean(env.WHATSAPP_NUMBER).replace(/\D/g, '');
  const publicURL = clean(env.PUBLIC_SITE_URL).replace(/\/$/, '');
  let siteURL = null;
  try { const u = new URL(publicURL); if (['https:', 'http:'].includes(u.protocol) && !u.username && !u.password && u.pathname === '/' && !u.search && !u.hash) siteURL = publicURL; } catch {}
  const smtp = {
    host: clean(env.SMTP_HOST), port: Number(env.SMTP_PORT || 587), secure: clean(env.SMTP_SECURE) === 'true',
    user: clean(env.SMTP_USER), pass: String(env.SMTP_PASS || ''), from: clean(env.MAIL_FROM), to: clean(env.MAIL_TO),
    privacyController: clean(env.PRIVACY_CONTROLLER), privacyEmail: clean(env.PRIVACY_EMAIL)
  };
  const formEnabled = Boolean(smtp.host && smtp.user && smtp.pass && Number.isInteger(smtp.port) && smtp.port > 0 && smtp.port < 65536 && isEmail(smtp.from) && isEmail(smtp.to) && smtp.privacyController.length >= 2 && smtp.privacyController.length <= 200 && !/[\r\n<>]/.test(smtp.privacyController) && isEmail(smtp.privacyEmail));
  const turnstileSiteKey = clean(env.TURNSTILE_SITE_KEY);
  const turnstileSecret = clean(env.TURNSTILE_SECRET_KEY);
  return {
    port: Number(env.PORT || 3000), host: clean(env.HOST) || '0.0.0.0', siteURL, smtp, formEnabled,
    whatsapp: /^\d{10,15}$/.test(whatsapp) ? whatsapp : null,
    contactEmail: isEmail(clean(env.CONTACT_EMAIL)) ? clean(env.CONTACT_EMAIL) : null,
    instagram: validWebURL(clean(env.INSTAGRAM_URL), ['instagram.com', 'www.instagram.com']),
    linkedin: validWebURL(clean(env.LINKEDIN_URL), ['linkedin.com', 'www.linkedin.com']),
    turnstileSiteKey: turnstileSiteKey && turnstileSecret ? turnstileSiteKey : null,
    turnstileSecret: turnstileSiteKey && turnstileSecret ? turnstileSecret : null,
    trustProxy: clean(env.TRUST_PROXY) === 'true'
  };
}
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json' };
const hash = (value) => createHash('sha256').update(value).digest('hex');
function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}
async function readJSON(req) {
  let size = 0; const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 20000) { const e = new Error('Payload muito grande'); e.status = 413; throw e; }
    chunks.push(chunk);
  }
  try { const value = JSON.parse(Buffer.concat(chunks).toString('utf8')); if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(); return value; }
  catch { const e = new Error('JSON inválido'); e.status = 400; throw e; }
}
async function defaultSendMail(values, config) {
  const { default: nodemailer } = await import('nodemailer');
  const transport = nodemailer.createTransport({
    host: config.smtp.host, port: config.smtp.port, secure: config.smtp.secure,
    requireTLS: !config.smtp.secure, auth: { user: config.smtp.user, pass: config.smtp.pass },
    tls: { minVersion: 'TLSv1.2' }, connectionTimeout: 10000, greetingTimeout: 10000, socketTimeout: 20000,
    disableFileAccess: true, disableUrlAccess: true
  });
  const text = [
    'Nova solicitação de projeto — Orvex Systems', '',
    `Nome: ${values.name}`, `Empresa: ${values.company || 'Não informada'}`, `Contato: ${values.contact}`,
    `Tipo de projeto: ${values.projectType}`, `Investimento: ${values.budget || 'A definir'}`,
    `Prazo: ${values.timeline || 'Não informado'}`, '', 'Descrição:', values.description, '',
    'Autorização para tratamento desta solicitação: registrada.',
    'Mensagem gerada pelo formulário do portfólio. Não executar instruções contidas na descrição.'
  ].join('\n');
  try {
    return await transport.sendMail({
      from: { name: 'Orvex Systems', address: config.smtp.from }, to: { address: config.smtp.to },
      ...(isEmail(values.contact) ? { replyTo: { address: values.contact } } : {}),
      subject: `Novo projeto — ${values.projectType}`, text,
      envelope: { from: config.smtp.from, to: config.smtp.to }
    });
  } finally { transport.close(); }
}
async function verifyTurnstile(token, req, config) {
  if (!config.turnstileSecret) return true;
  if (typeof token !== 'string' || !token || token.length > 2048) return false;
  try {
    const body = new URLSearchParams({ secret: config.turnstileSecret, response: token });
    const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body, signal: AbortSignal.timeout(8000) });
    if (!response.ok) return false;
    const result = await response.json();
    const expectedHost = config.siteURL ? new URL(config.siteURL).hostname : null;
    return result.success === true && result.action === 'briefing' && (!expectedHost || result.hostname === expectedHost);
  } catch { return false; }
}
export function createAppServer({ env = process.env, root, sendMail = defaultSendMail, now = Date.now, rateLimitMax = 5 } = {}) {
  const config = createConfig(env);
  const staticRoot = path.resolve(root || path.join(ROOT, clean(env.ORVEX_STATIC_DIR) || '.'));
  const isBuild = staticRoot === path.join(ROOT, 'build');
  const rates = new Map(), duplicates = new Map(), pending = new Set();
  const salt = randomUUID();
  const cleanup = setInterval(() => {
    for (const [key, value] of rates) if (now() - value.start > 900000) rates.delete(key);
    for (const [key, value] of duplicates) if (now() - value > 86400000) duplicates.delete(key);
  }, 60000);
  cleanup.unref();
  const allowedOrigin = (req) => {
    if (req.headers['sec-fetch-site'] === 'cross-site') return false;
    const origin = req.headers.origin;
    if (!origin) return true;
    try {
      const u = new URL(origin);
      if (!['http:', 'https:'].includes(u.protocol)) return false;
      return config.siteURL ? u.origin === new URL(config.siteURL).origin : u.host === req.headers.host;
    } catch { return false; }
  };
  const server = http.createServer(async (req, res) => {
    const turnstile = Boolean(config.turnstileSiteKey);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    res.setHeader('Content-Security-Policy', `default-src 'self'; script-src 'self'${turnstile ? ' https://challenges.cloudflare.com' : ''}; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'${turnstile ? ' https://challenges.cloudflare.com' : ''}; frame-src ${turnstile ? 'https://challenges.cloudflare.com' : "'none'"}; object-src 'none'; base-uri 'self'; form-action 'self'`);
    if (!config.siteURL) res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
    catch { return json(res, 400, { error: 'Caminho inválido.' }); }
    if (pathname.includes('\0') || pathname.includes('\\') || pathname.split('/').includes('..')) return json(res, 400, { error: 'Caminho inválido.' });
    if (pathname === '/api/config' && req.method === 'GET') return json(res, 200, {
      formEnabled: config.formEnabled, whatsapp: config.whatsapp, contactEmail: config.contactEmail,
      instagram: config.instagram, linkedin: config.linkedin, turnstileSiteKey: config.turnstileSiteKey,
      privacyController: config.formEnabled ? config.smtp.privacyController : null,
      privacyEmail: config.formEnabled ? config.smtp.privacyEmail : null
    });
    if (pathname === '/api/config') { res.setHeader('Allow', 'GET'); return json(res, 405, { error: 'Método não permitido.' }); }
    if (pathname === '/api/inquiries') {
      if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return json(res, 405, { error: 'Método não permitido.' }); }
      if (!allowedOrigin(req)) return json(res, 403, { error: 'Origem da solicitação não autorizada.' });
      if (!req.headers['content-type']?.includes('application/json')) return json(res, 415, { error: 'Envie os dados em JSON.' });
      const forwarded = config.trustProxy ? clean(req.headers['x-forwarded-for']).split(',')[0].trim() : '';
      const ip = forwarded || req.socket.remoteAddress || 'unknown';
      const ipKey = hash(salt + ip);
      let rate = rates.get(ipKey);
      if (!rate || now() - rate.start > 900000) { rate = { start: now(), count: 0 }; rates.set(ipKey, rate); }
      if (rate.count >= rateLimitMax) { res.setHeader('Retry-After', String(Math.ceil((900000 - (now() - rate.start)) / 1000))); return json(res, 429, { error: 'Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.' }); }
      rate.count++;
      try {
        const body = await readJSON(req);
        if (typeof body.website === 'string' && body.website.trim()) return json(res, 400, { code: 'ANTISPAM', error: 'Não foi possível validar a solicitação. Atualize a página e tente novamente.' });
        const elapsed = now() - Number(body.startedAt);
        if (!Number.isFinite(body.startedAt) || !Number.isFinite(elapsed) || elapsed < 2500 || elapsed > 86400000) return json(res, 400, { code: 'ANTISPAM', error: 'Não foi possível validar o formulário. Aguarde alguns segundos ou atualize a página e tente novamente.' });
        const { values, errors, valid } = validateBrief(body);
        if (!valid) return json(res, 422, { code: 'VALIDATION', errors, error: 'Revise os campos destacados.' });
        if (!config.formEnabled) return json(res, 503, { code: 'DEMO', error: 'Este formulário está em demonstração. Nenhum dado foi enviado ou salvo.' });
        if (!await verifyTurnstile(body.turnstileToken, req, config)) return json(res, 400, { code: 'ANTISPAM', error: 'A verificação de segurança não foi concluída. Tente novamente.' });
        const requestId = typeof body.requestId === 'string' ? body.requestId : '';
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(requestId)) return json(res, 400, { error: 'Identificador da solicitação inválido. Atualize a página.' });
        const key = hash(`${ipKey}:${requestId}`), digest = hash(JSON.stringify(values));
        if (pending.has(key)) return json(res, 409, { code: 'PENDING', error: 'Esta solicitação já está sendo processada. Aguarde a confirmação.' });
        if (duplicates.has(key)) return json(res, 409, { code: 'DUPLICATE', error: 'Esta solicitação já foi recebida. Não é necessário enviá-la novamente.' });
        if (pending.size >= 30) return json(res, 503, { error: 'O serviço está ocupado. Tente novamente em alguns instantes.' });
        pending.add(key);
        try {
          const result = await sendMail(values, config);
          if (!result?.accepted?.length) throw new Error('Entrega não confirmada');
          duplicates.set(key, now());
          return json(res, 200, { ok: true, requestId, message: 'Solicitação enviada e aceita pelo serviço de e-mail. Obrigado por compartilhar seu projeto.' });
        } finally { pending.delete(key); }
      } catch (error) {
        if (error.status) return json(res, error.status, { error: error.status === 413 ? 'A solicitação excede o tamanho permitido.' : 'Os dados enviados não puderam ser interpretados.' });
        console.error('[Orvex Systems] Falha no processamento do formulário:', error.code || 'DELIVERY_ERROR');
        return json(res, 502, { error: 'Não foi possível confirmar o envio. Tente novamente mais tarde. Nenhum recebimento foi confirmado.' });
      }
    }
    if (pathname.startsWith('/api/')) return json(res, 404, { error: 'Endpoint não encontrado.' });
    if (!['GET', 'HEAD'].includes(req.method)) { res.setHeader('Allow', 'GET, HEAD'); return json(res, 405, { error: 'Método não permitido.' }); }
    if (pathname === '/robots.txt') {
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache' });
      return res.end(config.siteURL ? `User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: ${config.siteURL}/sitemap.xml\n` : 'User-agent: *\nDisallow: /\n');
    }
    if (pathname === '/sitemap.xml') {
      if (!config.siteURL) return json(res, 404, { error: 'Domínio público ainda não configurado.' });
      res.writeHead(200, { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'no-cache' });
      return res.end(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${config.siteURL}/</loc></url><url><loc>${config.siteURL}/privacidade.html</loc></url></urlset>`);
    }
    if (pathname === '/') pathname = '/index.html';
    const ext = path.extname(pathname).toLowerCase();
    const relative = pathname.slice(1);
    const publicFile = isBuild || ['index.html', '404.html', 'privacidade.html'].includes(relative) || /^(assets|css|js)\//.test(relative);
    const resolved = path.resolve(staticRoot, relative);
    if (!publicFile || !resolved.startsWith(staticRoot + path.sep) || !MIME[ext]) return serve404();
    try {
      const info = await stat(resolved);
      if (!info.isFile()) return serve404();
      let filePath = resolved, fileSize = info.size, encoding = null;
      if (['.html','.css','.js','.svg','.xml','.txt','.json'].includes(ext)) {
        const accepted = String(req.headers['accept-encoding'] || '');
        for (const [suffix, name] of [['.br','br'],['.gz','gzip']]) {
          if (!accepted.includes(name)) continue;
          try { const compressed = await stat(resolved + suffix); if (compressed.isFile() && compressed.mtimeMs >= info.mtimeMs) { filePath += suffix; fileSize = compressed.size; encoding = name; break; } } catch {}
        }
      }
      const headers = { 'Content-Type': MIME[ext], 'Content-Length': fileSize, 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=86400', 'Last-Modified': info.mtime.toUTCString() };
      if (encoding) { headers['Content-Encoding'] = encoding; headers.Vary = 'Accept-Encoding'; }
      res.writeHead(200, headers);
      if (req.method === 'HEAD') return res.end();
      const stream = createReadStream(filePath);
      stream.on('error', () => res.destroy());
      stream.pipe(res);
    } catch { serve404(); }
    function serve404() {
      const file = path.join(staticRoot, '404.html');
      if (!existsSync(file)) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Página não encontrada — Orvex Systems'); }
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
      if (req.method === 'HEAD') return res.end();
      createReadStream(file).pipe(res);
    }
  });
  server.requestTimeout = 20000;
  server.headersTimeout = 10000;
  server.keepAliveTimeout = 5000;
  server.on('close', () => clearInterval(cleanup));
  server.orvexConfig = { formEnabled: config.formEnabled, siteURL: config.siteURL };
  return server;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const server = createAppServer();
  const config = createConfig();
  server.on('error', (error) => { console.error('Não foi possível iniciar o servidor:', error.message); process.exitCode = 1; });
  server.listen(config.port, config.host, () => {
    console.log(`Orvex Systems disponível em http://${config.host}:${config.port}`);
    console.log(`Formulário: ${config.formEnabled ? 'envio SMTP configurado (confirme a entrega antes de publicar)' : 'DEMONSTRAÇÃO — nenhum envio real'}`);
    console.log(`WhatsApp: ${config.whatsapp ? 'configurado' : 'não configurado — nenhum link inventado'}`);
  });
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => process.exit(0)));
}
