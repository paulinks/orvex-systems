import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { randomUUID } from 'node:crypto';
import { createAppServer, createConfig } from '../server.mjs';
import { validateBrief, isEmail, isPhone } from '../js/validation.js';

const blankEnv = { SMTP_HOST:'',SMTP_USER:'',SMTP_PASS:'',MAIL_FROM:'',MAIL_TO:'',PRIVACY_CONTROLLER:'',PRIVACY_EMAIL:'',WHATSAPP_NUMBER:'',CONTACT_EMAIL:'',PUBLIC_SITE_URL:'',TURNSTILE_SITE_KEY:'',TURNSTILE_SECRET_KEY:'',INSTAGRAM_URL:'',LINKEDIN_URL:'',ORVEX_STATIC_DIR:'' };
const configuredEnv = { ...blankEnv, SMTP_HOST:'smtp.example.test',SMTP_PORT:'587',SMTP_USER:'test-user',SMTP_PASS:'test-only-not-a-secret',MAIL_FROM:'site@example.test',MAIL_TO:'comercial@example.test',PRIVACY_CONTROLLER:'Controlador de teste',PRIVACY_EMAIL:'privacidade@example.test' };
const brief = (extra={}) => ({ name:'Pessoa de Teste',company:'Empresa de Teste',contact:'teste@example.test',projectType:'Site institucional',description:'Precisamos de um site institucional para apresentar a empresa e seus serviços.',budget:'',timeline:'',consent:true,website:'',startedAt:Date.now()-6000,requestId:randomUUID(),...extra });
async function withServer(t, options, run) {
  const server=createAppServer({env:blankEnv,...options});server.listen(0,'127.0.0.1');await once(server,'listening');
  t.after(()=>{server.close();server.closeAllConnections();});
  const base=`http://127.0.0.1:${server.address().port}`;
  const post=(body,headers={})=>fetch(base+'/api/inquiries',{method:'POST',headers:{'Content-Type':'application/json',...headers},body:typeof body==='string'?body:JSON.stringify(body)});
  return {base,post,server};
}
test('configuração pública não expõe segredos e não inventa contatos',async t=>{
  const {base}=await withServer(t,{env:configuredEnv},()=>{});
  const response=await fetch(base+'/api/config');const body=await response.json();
  assert.equal(response.status,200);assert.equal(body.formEnabled,true);assert.equal(body.whatsapp,null);assert.equal(body.contactEmail,null);
  for(const secret of ['smtp','pass','test-only-not-a-secret','test-user']) assert.equal(JSON.stringify(body).includes(secret),false);
  assert.equal(response.headers.get('cache-control'),'no-store');
});
test('configuração incompleta mantém demonstração e rejeita canais inválidos',()=>{
  const config=createConfig({...configuredEnv,PRIVACY_EMAIL:'',WHATSAPP_NUMBER:'123',CONTACT_EMAIL:'inválido',INSTAGRAM_URL:'https://evil.test/phish',PUBLIC_SITE_URL:'javascript:alert(1)'});
  assert.equal(config.formEnabled,false);assert.equal(config.whatsapp,null);assert.equal(config.contactEmail,null);assert.equal(config.instagram,null);assert.equal(config.siteURL,null);
});
test('validação compartilhada cobre obrigatórios, contato e opções',()=>{
  assert.equal(validateBrief({}).valid,false);assert.equal(validateBrief(brief()).valid,true);
  assert.equal(validateBrief(brief({contact:'inválido'})).valid,false);
  assert.equal(validateBrief(brief({contact:'+55 (11) 99999-9999'})).valid,true);
  assert.equal(validateBrief(brief({consent:false})).errors.consent.length>0,true);
  assert.equal(validateBrief(brief({projectType:'Inexistente'})).valid,false);
  assert.equal(validateBrief(brief({budget:'Valor arbitrário'})).valid,false);
  assert.equal(validateBrief(brief({description:'curto'})).valid,false);
  assert.equal(validateBrief(brief({description:'x'.repeat(4001)})).valid,false);
  assert.equal(validateBrief(brief({name:'Nome\r\nInjetado'})).valid,false);
  assert.equal(isEmail('a@b.c'),true);assert.equal(isEmail('a@b'),false);assert.equal(isPhone('(11) 99999-9999'),true);
});
test('modo demonstrativo nunca chama o serviço de envio',async t=>{
  let calls=0;const {base,post}=await withServer(t,{sendMail:async()=>{calls++;return {accepted:['ok']};}});
  const response=await post(brief());assert.equal(response.status,503);assert.equal((await response.json()).code,'DEMO');assert.equal(calls,0);
  assert.equal((await fetch(base+'/api/config').then(r=>r.json())).formEnabled,false);
});
test('validação do servidor ocorre antes do modo de envio',async t=>{
  const {post}=await withServer(t,{});const response=await post(brief({contact:'inválido'}));assert.equal(response.status,422);assert.ok((await response.json()).errors.contact);
});
test('honeypot, envio rápido e origem cruzada são bloqueados',async t=>{
  const {base,post}=await withServer(t,{});
  assert.equal((await post(brief({website:'spam'}))).status,400);
  assert.equal((await post(brief({startedAt:Date.now()}))).status,400);
  assert.equal((await post(brief(),{Origin:'https://untrusted.example.test'})).status,403);
  assert.equal((await fetch(base+'/api/inquiries',{method:'POST',headers:{'Content-Type':'application/json','Sec-Fetch-Site':'cross-site'},body:JSON.stringify(brief())})).status,403);
});
test('limita payload, tipo de conteúdo e métodos',async t=>{
  const {base,post}=await withServer(t,{});
  assert.equal((await post('x'.repeat(21000))).status,413);
  assert.equal((await fetch(base+'/api/inquiries',{method:'POST',body:'nome=teste'})).status,415);
  assert.equal((await fetch(base+'/api/inquiries')).status,405);
  assert.equal((await fetch(base+'/api/config',{method:'DELETE'})).status,405);
});
test('envio configurado exige aceitação do transporte e impede duplicidade',async t=>{
  let calls=0;const {post}=await withServer(t,{env:configuredEnv,sendMail:async()=>{calls++;return {accepted:['comercial@example.test']};}});
  const data=brief();const first=await post(data);assert.equal(first.status,200);assert.equal((await first.json()).ok,true);
  const duplicate=await post(data);assert.equal(duplicate.status,409);assert.equal((await duplicate.json()).code,'DUPLICATE');assert.equal(calls,1);
});
test('envios concorrentes com o mesmo identificador não duplicam entrega',async t=>{
  let calls=0;const {post}=await withServer(t,{env:configuredEnv,rateLimitMax:10,sendMail:async()=>{calls++;await new Promise(r=>setTimeout(r,80));return {accepted:['ok']};}});
  const data=brief();const responses=await Promise.all([post(data),post(data)]);assert.deepEqual(responses.map(r=>r.status).sort(),[200,409]);assert.equal(calls,1);
});
test('falha ou não aceite do transporte nunca retorna sucesso',async t=>{
  let calls=0;const {post}=await withServer(t,{env:configuredEnv,rateLimitMax:10,sendMail:async()=>{calls++;if(calls===1)throw new Error('falha simulada');return {accepted:[]};}});
  const data=brief();assert.equal((await post(data)).status,502);assert.equal((await post(data)).status,502);assert.equal(calls,2);
});
test('limite de tentativas responde 429 com Retry-After',async t=>{
  const {post}=await withServer(t,{rateLimitMax:2});
  assert.equal((await post(brief())).status,503);assert.equal((await post(brief())).status,503);
  const response=await post(brief());assert.equal(response.status,429);assert.ok(Number(response.headers.get('retry-after'))>0);
});
test('Turnstile configurado exige token antes do envio',async t=>{
  let calls=0;const {post}=await withServer(t,{env:{...configuredEnv,TURNSTILE_SITE_KEY:'test-site',TURNSTILE_SECRET_KEY:'test-secret'},sendMail:async()=>{calls++;return {accepted:['ok']};}});
  const response=await post(brief());assert.equal(response.status,400);assert.equal((await response.json()).code,'ANTISPAM');assert.equal(calls,0);
});
test('arquivos privados não são servidos e páginas inexistentes retornam 404 real',async t=>{
  const {base}=await withServer(t,{});
  for(const route of ['/.env','/server.mjs','/package.json','/tests/server.test.mjs']) assert.equal((await fetch(base+route)).status,404);
  assert.equal((await fetch(base+'/assets/%2e%2e%2fserver.mjs')).status,400);
  const missing=await fetch(base+'/pagina-inexistente');assert.equal(missing.status,404);assert.match(await missing.text(),/não<br>\s*está no mapa/);
  assert.match(await fetch(base+'/robots.txt').then(r=>r.text()),/Disallow: \//);
  assert.equal((await fetch(base+'/sitemap.xml')).status,404);
});
test('headers de segurança não bloqueiam o preview incorporado',async t=>{
  const {base}=await withServer(t,{});const response=await fetch(base+'/');
  assert.equal(response.headers.get('x-content-type-options'),'nosniff');assert.match(response.headers.get('content-security-policy'),/default-src 'self'/);
  assert.equal(response.headers.get('x-frame-options'),null);assert.equal(response.headers.get('x-robots-tag'),'noindex, nofollow');
});
test('domínio confirmado habilita sitemap e robots públicos',async t=>{
  const {base}=await withServer(t,{env:{...blankEnv,PUBLIC_SITE_URL:'https://orvex.example.test'}});
  const response=await fetch(base+'/sitemap.xml');assert.equal(response.status,200);assert.match(await response.text(),/https:\/\/orvex\.example\.test\/privacidade\.html/);
  assert.match(await fetch(base+'/robots.txt').then(r=>r.text()),/Sitemap: https:\/\/orvex\.example\.test\/sitemap\.xml/);
});
