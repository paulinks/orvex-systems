import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

async function home(page) { await page.goto('/'); await expect(page.locator('#briefing-form')).toHaveAttribute('data-mode','demo'); }
async function fillBrief(page) {
  await page.locator('#name').fill('Pessoa de Teste');await page.locator('#company').fill('Empresa de Teste');
  await page.locator('#contact').fill('teste@example.test');await page.locator('#projectType').selectOption('Site institucional');
  await page.locator('#description').fill('Precisamos de um site institucional para apresentar nossa empresa e serviços.');await page.locator('#consent').check();
}
async function openProject(page,index) {
  await page.locator(`[data-slide="${index}"]`).click();
  await page.locator('.project-slide[aria-hidden="false"] [data-open-project]').click();
  await expect(page.locator('#experience-dialog')).toBeVisible();
}
test('estrutura, grafia, recursos e links locais',async({page,request})=>{
  const errors=[];page.on('pageerror',e=>errors.push(e.message));await home(page);
  expect((await page.locator('h1').innerText()).replace(/\s+/g,' ')).toBe('Seu negócio merece uma presença digital à altura.');
  for(const id of ['inicio','solucoes','portfolio','laboratorio','processo','sobre','faq','contato']) await expect(page.locator('#'+id)).toHaveCount(1);
  const anchors=await page.locator('a[href^="#"]').evaluateAll(links=>links.map(a=>a.getAttribute('href')));
  for(const href of anchors) expect(await page.locator(href).count(),href).toBeGreaterThan(0);
  const images=await page.locator('img').evaluateAll(imgs=>[...new Set(imgs.map(i=>i.getAttribute('src')))]);
  for(const src of images) expect((await request.get(src)).status(),src).toBe(200);
  expect(errors).toEqual([]);
  await expect(page).toHaveTitle(/Orvex Systems/);
  expect((await request.get('/pagina-inexistente')).status()).toBe(404);
  expect((await request.get('/privacidade.html')).status()).toBe(200);
});
test('carrossel por setas, indicadores e teclado; modal devolve foco',async({page})=>{
  await home(page);await page.locator('.carousel-next').click();await expect(page.locator('#project-current')).toHaveText('02');
  await page.locator('.project-carousel').focus();await page.keyboard.press('End');await expect(page.locator('#project-current')).toHaveText('04');
  await page.keyboard.press('Home');await expect(page.locator('#project-current')).toHaveText('01');
  await page.locator('[data-slide="2"]').click();await expect(page.locator('#project-current')).toHaveText('03');
  const trigger=page.locator('.project-slide[aria-hidden="false"] [data-open-project]');await trigger.click();await expect(page.locator('#experience-title')).toHaveText('Orvex Corporate');
  for(let i=0;i<8;i++){await page.keyboard.press('Tab');expect(await page.evaluate(()=>document.getElementById('experience-dialog').contains(document.activeElement))).toBe(true);}
  await page.keyboard.press('Escape');await expect(page.locator('#experience-dialog')).not.toBeVisible();await expect(trigger).toBeFocused();
  expect(await page.locator('.project-slide[inert]').count()).toBe(3);
});
test('carrossel reconhece gesto horizontal',async({page},testInfo)=>{
  await home(page);const track=page.locator('.project-track');await track.scrollIntoViewIfNeeded();
  if(testInfo.project.name==='mobile'){
    const box=await track.boundingBox(),cdp=await page.context().newCDPSession(page);const x=box.x+box.width*.8,y=box.y+Math.min(180,box.height/2);
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x-150,y}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await cdp.detach();
  } else {await track.dispatchEvent('pointerdown',{pointerType:'touch',clientX:300,clientY:200});await track.dispatchEvent('pointerup',{pointerType:'touch',clientX:100,clientY:205});}
  await expect(page.locator('#project-current')).toHaveText('02');
});
test('catálogo: filtros, busca, variantes, consulta e resumo',async({page})=>{
  await home(page);const lab=page.locator('#lab-panel');await lab.locator('[data-category="Iluminação"]').click();await expect(lab.locator('.demo-product-card')).toHaveCount(2);
  await lab.locator('[data-catalog-search]').fill('Arco');await expect(lab.locator('.demo-product-card')).toHaveCount(1);
  await lab.locator('[data-catalog-search]').fill('inexistente');await expect(lab.locator('.demo-empty')).toContainText('Nenhum item');await lab.locator('[data-action="reset-filters"]').click();await expect(lab.locator('.demo-product-card')).toHaveCount(6);
  await lab.locator('.demo-product-image[data-product="f01"]').click();await lab.locator('[data-variant="Carvalho natural"]').click();await expect(lab.locator('[data-variant-label]')).toHaveText('Carvalho natural');
  await lab.locator('[data-action="add"]').click();await expect(lab.locator('[data-quote-count]')).toHaveText('1');await lab.locator('[data-action="quote"]').click();
  await lab.locator('[data-remove]').click();await expect(lab.locator('.demo-empty')).toBeVisible();await lab.locator('.demo-empty [data-action="back"]').click();
  await lab.locator('.demo-product-image[data-product="f02"]').click();await lab.locator('[data-action="add"]').click();await lab.locator('[data-action="quote"]').click();
  await lab.locator('[data-quote-note]').fill('Consulta de teste, sem pedido real.');await lab.locator('[data-action="prepare"]').click();await expect(lab.locator('[data-summary-text]')).toHaveValue(/Luminária Arco/);
  await lab.locator('[data-action="use-briefing"]').click();await expect(page.locator('#projectType')).toHaveValue('Catálogo digital');await expect(page.locator('#description')).toHaveValue(/Luminária Arco/);
});
test('dashboard: período, gráfico, pedidos, status, CSV e estoque local',async({page})=>{
  await home(page);await page.locator('#tab-dashboard').click();const lab=page.locator('#lab-panel');
  await expect(lab.locator('.demo-metrics article').first().locator('strong')).toHaveText('08');await lab.locator('[data-dashboard-period]').selectOption('7');await expect(lab.locator('.demo-metrics article').first().locator('strong')).toHaveText('04');
  await lab.locator('[data-chart="line"]').click();await expect(lab.locator('[data-chart="line"]')).toHaveAttribute('aria-pressed','true');await lab.locator('.demo-chart-data summary').click();await expect(lab.locator('.demo-chart-data table')).toBeVisible();
  await lab.locator('.demo-dashboard-sidebar [data-dashboard-view="orders"]').click();await lab.locator('[data-order-search]').fill('1048');await expect(lab.locator('.demo-table tbody tr')).toHaveCount(1);
  await lab.locator('[data-order="1048"]').click();await lab.locator('[data-order-status]').selectOption('Concluído');await lab.locator('[data-action="save-status"]').click();await expect(lab.locator('.demo-order-detail')).toContainText('Concluído');
  const download=page.waitForEvent('download');await lab.locator('[data-action="export"]').click();expect((await download).suggestedFilename()).toBe('orvex-business-pedidos-ficticios.csv');
  await lab.locator('.demo-dashboard-sidebar [data-dashboard-view="products"]').click();await lab.locator('[data-stock="f01"][data-delta="1"]').click();await expect(lab.locator('[data-stock-value="f01"]')).toHaveText('13');
  await lab.locator('[data-action="reset-dashboard"]').click();await lab.locator('.demo-dashboard-sidebar [data-dashboard-view="products"]').click();await expect(lab.locator('[data-stock-value="f01"]')).toHaveText('12');
});
test('página comercial e navegação por teclado no laboratório',async({page})=>{
  await home(page);await page.locator('#tab-catalog').focus();await page.keyboard.press('ArrowRight');await expect(page.locator('#tab-dashboard')).toHaveAttribute('aria-selected','true');await page.keyboard.press('End');await expect(page.locator('#tab-commercial')).toHaveAttribute('aria-selected','true');
  const lab=page.locator('#lab-panel');await lab.locator('.demo-corporate-header [data-corporate-section="servicos"]').click();await expect(lab.locator('.demo-corporate-services')).toBeVisible();
  await lab.locator('.demo-corporate-header [data-corporate-section="sobre"]').click();await expect(lab.locator('.demo-corporate-values')).toBeVisible();
  await lab.locator('.demo-corporate-header [data-corporate-section="contato"]').click();await lab.locator('[data-action="corporate-briefing"]').click();await expect(page.locator('#projectType')).toHaveValue('Site institucional');
});
test('quatro conceitos abrem e o catálogo industrial funciona',async({page})=>{
  await home(page);for(const [index,name] of [[0,'Orvex Commerce'],[1,'Orvex Business'],[2,'Orvex Corporate'],[3,'Orvex Industrial']]){await openProject(page,index);await expect(page.locator('#experience-title')).toHaveText(name);await page.locator('#experience-dialog [data-close]').click();}
  await openProject(page,3);const demo=page.locator('#experience-content');await demo.locator('[data-catalog-search]').fill('RL-6204');await expect(demo.locator('.demo-product-card')).toHaveCount(1);await demo.locator('.demo-product-image').click();
  await demo.locator('[data-quantity="1"]').click();await expect(demo.locator('[data-quantity-input]')).toHaveValue('2');await demo.locator('[data-action="add"]').click();await expect(demo.locator('[data-quote-count]')).toHaveText('2');
  await demo.locator('[data-action="quote"]').click();await demo.locator('[data-action="prepare"]').click();await expect(demo.locator('[data-summary-text]')).toHaveValue(/2× Rolamento de esferas/);await page.keyboard.press('Escape');
});
test('formulário demonstrativo valida sem transmitir nem confirmar envio',async({page})=>{
  let posts=0;page.on('request',r=>{if(r.url().includes('/api/inquiries')&&r.method()==='POST')posts++;});await home(page);
  await page.locator('#form-submit').click();await expect(page.locator('#name')).toHaveAttribute('aria-invalid','true');await expect(page.locator('#contact-error')).not.toBeEmpty();
  await fillBrief(page);await page.locator('#form-submit').click();await expect(page.locator('#form-status')).toContainText('nenhum dado foi enviado ou salvo');expect(posts).toBe(0);
  await page.locator('.consent-field [data-privacy]').click();await expect(page.locator('#privacy-dialog')).toBeVisible();await page.keyboard.press('Escape');
  await page.locator('.contact-channel [data-whatsapp]').click();await expect(page.locator('#contact-dialog')).toContainText('ainda não foi configurado');await page.locator('#contact-to-form').click();await expect(page.locator('#contact-dialog')).not.toBeVisible();
});
test('estados de envio real são exercitados com respostas controladas de teste',async({page})=>{
  await page.route('**/api/config',route=>route.fulfill({json:{formEnabled:true,whatsapp:null,contactEmail:null,privacyController:'Controlador de teste',privacyEmail:'privacidade@example.test'}}));
  let status=502;let payload=null;let release;let firstRequest=true;const gate=new Promise(resolve=>release=resolve);
  await page.route('**/api/inquiries',async route=>{payload=route.request().postDataJSON();if(firstRequest){firstRequest=false;await gate;}await route.fulfill({status,json:status===200?{ok:true,message:'Solicitação enviada e aceita pelo serviço de e-mail.'}:{error:'Não foi possível confirmar o envio. Nenhum recebimento foi confirmado.'}});});
  await homeForConfiguredForm(page);await fillBrief(page);const readyTime=await page.evaluate(()=>performance.now());await page.waitForFunction(start=>performance.now()-start>2700,readyTime);await page.locator('#form-submit').click();await expect(page.locator('#briefing-form')).toHaveAttribute('aria-busy','true');await expect(page.locator('#form-submit')).toBeDisabled();release();
  await expect(page.locator('#form-status')).toContainText('Não foi possível confirmar');await expect(page.locator('#name')).toHaveValue('Pessoa de Teste');expect(payload.requestId).toMatch(/^[0-9a-f-]{36}$/);
  status=200;await page.locator('#form-submit').click();await expect(page.locator('#form-status')).toHaveClass(/success/);await expect(page.locator('#form-status')).toContainText('aceita pelo serviço de e-mail');await expect(page.locator('#name')).toHaveValue('');
});
async function homeForConfiguredForm(page){await page.goto('/');await expect(page.locator('#briefing-form')).toHaveAttribute('data-mode','ready');}
test('serviços pré-selecionam o briefing e FAQs abrem',async({page})=>{
  await home(page);await page.locator('[data-project-type="Sistema personalizado"]').click();await expect(page.locator('#projectType')).toHaveValue('Sistema personalizado');
  const faq=page.locator('.faq-list details');await faq.nth(1).locator('summary').click();await expect(faq.nth(1)).toHaveAttribute('open','');await faq.nth(2).locator('summary').click();await expect(faq.nth(2)).toHaveAttribute('open','');await expect(faq.nth(1)).not.toHaveAttribute('open','');
});
test('menu móvel, foco e ausência de overflow em cinco larguras',async({page,isMobile})=>{
  await home(page);if(isMobile){await page.locator('#menu-toggle').click();await expect(page.locator('#mobile-menu')).toBeVisible();await page.keyboard.press('Escape');await expect(page.locator('#menu-toggle')).toBeFocused();await page.locator('#menu-toggle').click();await page.locator('#mobile-menu a[href="#solucoes"]').click();await expect(page.locator('#mobile-menu')).not.toBeVisible();await expect(page).toHaveURL(/#solucoes/);}
  for(const width of [320,390,768,1024,1440]){await page.setViewportSize({width,height:900});await page.waitForTimeout(70);const size=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth}));expect(size.document,`overflow em ${width}px`).toBeLessThanOrEqual(size.viewport);}
});
test('axe: página, laboratório, conceitos e diálogos sem violações WCAG A/AA testáveis',async({page})=>{
  await home(page);const audit=async selector=>{let builder=new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']);if(selector)builder=builder.include(selector);const result=await builder.analyze();expect(result.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}))).toEqual([]);};
  await audit();await page.locator('#tab-dashboard').click();await audit('#laboratorio');await page.locator('#tab-commercial').click();await audit('#laboratorio');
  for(const index of [0,1,2,3]){await openProject(page,index);await audit('#experience-dialog');await page.keyboard.press('Escape');}
  await page.locator('.consent-field [data-privacy]').click();await audit('#privacy-dialog');await page.keyboard.press('Escape');
});
test('movimento reduzido mantém conteúdo acessível',async({page})=>{
  await home(page);await page.emulateMedia({reducedMotion:'reduce'});expect(await page.locator('.hero-line>span').first().evaluate(el=>getComputedStyle(el).animationDuration)).toBe('1e-05s');
  expect(await page.locator('.project-track').evaluate(el=>getComputedStyle(el).transitionDuration)).toBe('1e-05s');await expect(page.locator('#services-title')).toBeVisible();
});
test('metadados e privacidade refletem ambiente sem domínio',async({page,request})=>{
  await home(page);await expect(page.locator('meta[name="description"]')).toHaveAttribute('content',/Orvex Systems/);expect((await request.get('/robots.txt').then(r=>r.text()))).toContain('Disallow: /');
  await page.goto('/privacidade.html');await expect(page.locator('#privacy-mode')).toContainText('modo de demonstração');await expect(page.locator('h1')).toHaveText('Privacidade e dados.');
});
